# google-secops.md — Vendor Summary
# Covers: Google SecOps (Chronicle) SIEM, log ingestion, UDM queries, alerts

## Architecture in This Environment
- SIEM platform: Google SecOps (formerly Chronicle)
- Log ingestion: all DC security event logs, Entra logs forwarded via CRIBL
- CRIBL: log aggregation/routing layer — all sources funnel through CRIBL
- GTI: Google Threat Intelligence integrated into SecOps — IOC enrichment automatic
- Datadog: separate monitoring platform (metrics + AD security events also sent here)

## LOG COVERAGE MAP — What IS and IS NOT in SIEM
| Log source | In SecOps? | Notes |
|-----------|-----------|-------|
| AD Domain Controller security logs | YES | Via CRIBL |
| Entra ID / Azure AD sign-in logs | YES | Via CRIBL |
| Silverfort auth events | VERIFY | Should be — confirm active |
| Okta system log | NO — GAP | Not forwarded — detection blind spot |
| Arcon PAM session logs | VERIFY | Check forwarding status |
| Arcon EPM elevation events | VERIFY | Check forwarding status |
| Non-domain-joined server auth | NO — GAP | No DC for these servers |
| Linux RHEL auth logs | VERIFY | Need direct log forwarding |
| Palo Alto firewall | VERIFY | Standard enterprise SIEM source |

## UDM Query Patterns (Chronicle Query Language)
```
# AD auth failures
metadata.event_type = "USER_LOGIN" AND
security_result.action = "BLOCK" AND
target.user.user_domain != "" AND
timestamp.seconds > [epoch-minus-1h]

# Privileged account activity
metadata.event_type = "USER_LOGIN" AND
principal.user.userid IN ["Administrator", "admin", "[privileged-account]"] AND
timestamp.seconds > [epoch-minus-24h]

# Lateral movement indicator (logon type 3 to many targets)
metadata.event_type = "USER_LOGIN" AND
network.session_id = "3" AND
principal.ip != "" 
| group_by principal.user.userid
| count() > 5

# DCSync detection (Event ID 4662 with Replicating Directory Changes)
metadata.vendor_name = "Microsoft" AND
metadata.product_name = "Windows" AND
target.process.command_line contains "1131f6ad-9c07-11d1-f79f-00c04fc2dcd2"

# Service account activity outside business hours
principal.user.userid contains "svc_" AND
timestamp.get_hour(timestamp.seconds) NOT IN [7,8,9,10,11,12,13,14,15,16,17]
```

## Key Event IDs (AD)
4624 (success logon), 4625 (failed logon), 4648 (explicit credential use),
4662 (object operation — DCSync), 4720 (account created), 4725 (account disabled),
4768 (Kerberos TGT), 4769 (Kerberos service ticket — watch RC4), 4771 (Kerberos failure),
4776 (NTLM auth), 4672 (special privileges), 4688 (process creation)

## Security Baseline
- All DC security logs forwarded via CRIBL — verify no gaps
- Entra logs forwarded — verify sign-in logs AND audit logs included
- CRIBL pipeline health monitoring — Datadog monitors CRIBL agent status
- Retention policy: verify compliance with NYDFS §500.6 (3 years financial, 5 years cyber)
- GTI IOC enrichment: automatic for all external IPs in SecOps logs
