# VENDOR-SUMMARIES-INDEX.md
# Pre-digested vendor reference — loaded surgically, not in bulk.
# Each vendor summary: ~400-600 tokens. Load only the relevant one per session.
# Raw vendor manuals: vendor-docs-raw/ — access surgically with explicit prompt.

## Available summaries
- microsoft-ad-entra.md       — Active Directory, Entra ID, ADConnect, GPO, Kerberos
- okta.md                     — Okta SSO, SCIM, MFA, sync agents, Workflows
- arcon-pam-epm.md            — Arcon PAM vault, session brokering, JIT; Arcon EPM elevation
- opentext-netiq-oig.md       — NetIQ/MyAccess ILM, OIG RBAC/SoD/certifications, fulfillers
- siteminder.md               — CA SiteMinder Policy Server, web agents, federation
- specops.md                  — Specops Password Manager, breach detection, self-service reset
- radiant-logic.md            — RadiantOne VDS, virtual directory, identity aggregation
- silverfort.md               — Silverfort auth monitoring, MFA enforcement, lateral movement detection
- groupid.md                  — GroupID / Imanami, AD group lifecycle, group attestation
- keyfactor.md                — Keyfactor CA, certificate lifecycle, SCEP/ACME

## How to load in a session
Add to SESSION.md load list:
  knowledge-base/vendor-summaries/[tool-name].md

## How to access raw manuals (surgical)
Add to your Claude Code prompt:
  "Load vendor-docs-raw/[filename]. Find [specific topic]."
