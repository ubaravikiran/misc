# silverfort.md — Vendor Summary
# Covers: Silverfort auth monitoring, MFA enforcement, lateral movement detection

## Architecture in This Environment
- Silverfort acts as auth monitoring proxy across the enterprise
- Sees ALL authentication events from covered domains
- Can enforce MFA on any protocol (including NTLM, Kerberos, LDAP — legacy protocol MFA)
- Lateral movement detection: flags when accounts authenticate to unusual targets
- Coverage: core AD domains (AM/HS/MS) — non-domain-joined servers are a gap
- Integration: alerts flow to Google SecOps (verify this is active)

## Key Capabilities
- MFA enforcement without requiring app-level integration (protocol-level)
- Service account behavior baselining — flags anomalous service account auth
- Ransomware protection: detects lateral movement patterns early
- Non-human identity (NHI) visibility: tracks service account auth patterns

## Common Failure Modes
| Symptom | First check | Action |
|---------|------------|--------|
| Silverfort MFA challenge not appearing | Policy applied to user? Agent active? | Silverfort admin → Policies → user policy assignment |
| False positive MFA block | Legitimate service account flagged? | Silverfort admin → Alerts → whitelist if legitimate |
| Agent offline on a DC | Service running? Network connectivity? | Check Silverfort agent service on DC + event log |
| Alert storm from service account | SA doing bulk operations legitimately? | Review SA behavior — whitelist or scope the operation |
| Lateral movement alert | Investigate immediately | Run /investigate mode — query Silverfort logs + DC event log |

## Key Alert Types
| Alert | Meaning | Action |
|-------|---------|--------|
| Anomalous resource access | Account accessing unusual target | Investigate — potential lateral movement |
| Service account behavior anomaly | SA deviating from baseline | Check if legitimate bulk operation or compromise |
| NTLM downgrade detected | Auth downgrade from Kerberos | Investigate — potential pass-the-hash setup |
| Brute force detected | Multiple failed auth attempts | Lock account, investigate source IP with GTI |
| Admin account activity outside hours | Privileged account used at unusual time | Investigate immediately |

## Integration with SIEM
Forward Silverfort alerts to Google SecOps:
- Auth anomaly events → SecOps alert
- Lateral movement detected → SecOps high-priority alert
- MFA policy violation → SecOps event

## Security Baseline
- All core domain DCs have Silverfort agents
- Service account baselines established for all production SAs in PAM vault
- Silverfort alert forwarding to SIEM: verify active
- Non-domain-joined server gap: documented in gap register
- Silverfort admin access: restricted to FID team only
