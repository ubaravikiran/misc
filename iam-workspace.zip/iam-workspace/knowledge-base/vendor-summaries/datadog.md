# datadog.md — Vendor Summary
# Covers: Datadog infrastructure monitoring, AD security events, metrics, logs

## Architecture in This Environment
- Datadog agents deployed on ALL servers in the enterprise
- AD security event logs also sent to Datadog (in addition to Google SecOps)
- Metrics: CPU, memory, disk, network for all servers
- Application performance monitoring on select applications
- Datadog MCP: available in this workspace — query metrics and dashboards programmatically
- Dashboards: some IAM-relevant dashboards may exist — check via MCP

## Using Datadog MCP in Sessions
```
# Query via mcp__datadog__* tools
# Examples of what to query:
- DC health metrics (CPU/memory on domain controllers)
- Arcon PAM server health
- ADConnect server metrics
- Authentication error rate trends
- Server uptime for IAM-critical infrastructure
```

## Common IAM Use Cases for Datadog
| Use case | What to query | Metric |
|----------|-------------|--------|
| DC performance during auth spike | system.cpu.user on DC hosts | Should be < 70% during normal auth |
| PAM vault server health | system.mem.used on Arcon hosts | Memory pressure during high checkout volume |
| ADConnect sync lag | Custom metric if instrumented | Time since last successful sync |
| Server offline detection | system.uptime on IAM servers | Alert if < last check-in |
| Auth error rate | Custom AD event metric if configured | Spike in 4625 events = potential attack |

## Key Monitors to Verify Active
| Monitor | Alert condition |
|---------|----------------|
| DC service availability | Any core DC agent offline > 5 min |
| PAM vault connectivity | Arcon PAM agent offline |
| ADConnect server health | ADConnect server metrics degraded |
| Auth failure rate | Event ID 4625 count > baseline + 3 sigma |

## Security Baseline
- Datadog agents on all servers — verify coverage includes non-domain-joined servers
- API keys in Arcon PAM vault (or 1Password) — not hardcoded in agent configs
- Datadog access control: least privilege — only IAM team has infrastructure dashboard access
- Integration with SIEM: Datadog can forward to Google SecOps — verify if configured
