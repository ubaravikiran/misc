# opentext-netiq-ig.md — Vendor Summary
# Covers: OpenText NetIQ / MyAccess (ILM), OpenText Identity Governance (IG)
# NOTE: OIG renamed to IG throughout this workspace

## NetIQ / MyAccess Architecture
- ILM engine: handles provisioning/de-provisioning of PRIMARY accounts only
- On Joiner: enables AD account, creates Exchange mailbox, assigns Entra license
- On Leaver: disables account
- On Rebadge: keeps old account active 30 days, provisions new account
- Does NOT provision secondary accounts, ghost accounts, or NHI
- Does NOT assign birthright roles/groups (this is done via bot → ServiceNow ticket → manual)
- Connected systems: AD (core domains), Exchange (direct), Entra (direct)

## IG Architecture (OpenText Identity Governance)
- PRODUCTION STATUS: Deployed but NOT enterprise-functional
- Performance and functionality issues active
- Opentext Professional Services engagement ongoing — progress slow
- Current scope: IAM department pilot with RBAC only
- Collectors operational: AD API collector, Entra API collector, Okta MANUAL CSV
- Fulfillers: standalone PowerShell scripts (no version control, no code review — SDLC gap)
- Fulfiller service accounts: stored in Arcon PAM vault
- Access certifications: NOT YET ACTIVE enterprise-wide (manual process)
- SoD enforcement: NOT YET ACTIVE (manual process)
- Leadership decision pending: fix vs replace IG

## Common Failure Modes — NetIQ
| Symptom | First check | Action |
|---------|------------|--------|
| New user account not created | Workday/Simplify/PMAC event triggered? | Check HR feed log → NetIQ event log |
| Account not disabled on termination | Termination event received by NetIQ? | NetIQ → Identity Vault → user record → workflow log |
| Mailbox not created | Exchange connector status? Exchange service account? | NetIQ → Exchange connector → provisioning log |
| Entra license not assigned | Entra connector status? License pool available? | NetIQ → Entra connector → provisioning log |
| Rebadge — wrong account in 30-day window | afiExternalUserID correctly mapped? | Check both old and new account for key attribute |

## Common Failure Modes — IG
| Symptom | First check | Action |
|---------|------------|--------|
| IG collector not running | Performance issue? Service running? | IG admin → Collectors → status |
| Fulfiller script fails | PowerShell error? Service account credential? | Check IG fulfiller log + Arcon PAM vault for SA |
| Okta data stale in IG | Manual CSV not uploaded? | IG → Okta data source → last import date |
| IG UI performance degraded | Known issue | Escalate to Opentext PS — document in incident |
| RBAC model not reflecting AD changes | AD collector last run? | IG → AD collector → last collection timestamp |

## Key Log Events
| System | Log location | What to check |
|--------|-------------|---------------|
| NetIQ | Identity Vault event log | Provisioning event status — created/modified/disabled |
| NetIQ | Driver log | Connector-specific errors (Exchange, Entra) |
| IG | Application log | Collector errors, fulfiller errors |
| IG | Workflow log | Access request workflow status |

## Security Baseline
- NetIQ service accounts: in Arcon PAM vault
- IG fulfiller service accounts: in Arcon PAM vault (least privilege scope critical — review)
- IG fulfiller scripts: NEED version control and peer review (current gap — SDLC policy violation)
- NetIQ driver service accounts: password rotation policy active
- IG RBAC model: reviewed quarterly (manual — IG not yet automating this)
