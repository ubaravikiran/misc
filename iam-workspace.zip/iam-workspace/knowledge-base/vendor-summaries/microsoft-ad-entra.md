# microsoft-ad-entra.md — Vendor Summary
# Covers: Active Directory (multi-forest/domain), Azure AD / Entra ID, ADConnect, GPO, Kerberos
# ~500 tokens. Load when AD/Entra is involved in the session.

---

## Architecture in This Environment
- Multi-forest: Core forest (AM/HS/MS domains), PCI forest (one-way trust — PCI trusts Corp, NOT reverse), DMZ forest (minimal trusts)
- ADConnect syncs core domain users to Entra ID (not PCI, not DMZ)
- Okta agents sync from core + other domains separately
- RadiantLogic aggregates across all forests for unified LDAP view
- Silverfort monitors all authentication events across all forests

## Key Integration Points
| Target | Method | Notes |
|--------|--------|-------|
| Entra ID | ADConnect | Core domain only; attribute filtering matters |
| Okta | AD sync agents | Core + other domains; separate from ADConnect |
| NetIQ/MyAccess | LDAP + AD APIs | Authoritative for primary account lifecycle |
| Arcon PAM | Service account auth | PAM vault stores creds; agents connect via svc accts |
| OIG | API collector (AD/Entra) | Collects identities + entitlements |
| Google SecOps SIEM | DC security event logs via CRIBL | All DC logs shipped |

## Common Failure Modes & First Checks
| Symptom | First check | Tool/command |
|---------|------------|--------------|
| User auth failure | Account enabled? Locked? Password expired? | `Get-ADUser -Identity [user] -Properties *` |
| Service account auth failure | Account enabled? Password expired? PAM vault current? | AD check + Arcon PAM rotation log |
| Kerberos error (KDC_ERR_*) | Clock skew? SPN duplicate? Delegation misconfigured? | `klist`, `setspn -Q */*`, time sync check |
| ADConnect sync failure | Delta sync error? Attribute rule violation? | Entra Connect Health portal + sync log |
| GPO not applying | RSOP? OU link order? WMI filter? | `gpresult /h report.html` on affected machine |
| Replication error | USN rollback? Lingering objects? Network? | `repadmin /showrepl`, `repadmin /replsummary` |
| LDAP signing failure | Client doesn't support signing? Policy mismatch? | Event ID 2886/2887 on DCs |
| Ghost account not found | Created under AM OpCo? afiExternalUserID set? | Cross-domain LDAP search |

## Key Event IDs (DC Security Log)
| Event ID | Meaning | When to care |
|----------|---------|-------------|
| 4624 | Successful logon | Baseline; correlate logon type (3=network, 10=remote) |
| 4625 | Failed logon | Lockout investigation; brute force detection |
| 4648 | Logon with explicit credentials | Lateral movement indicator |
| 4662 | Operation on AD object | DCSync detection (watch for Replicating Directory Changes) |
| 4720 | Account created | New account provisioning — was it via NetIQ or manual? |
| 4725 | Account disabled | Termination — was it timely? |
| 4768 | Kerberos TGT request | Auth baseline |
| 4769 | Kerberos service ticket | Kerberoasting detection (RC4 encryption type) |
| 4771 | Kerberos pre-auth failure | Bad password or clock skew |
| 4776 | NTLM auth attempt | NTLM usage — should be reducing |
| 4672 | Special privileges assigned | Admin logon |
| 4688 | Process creation (with cmdline) | PowerShell execution, script activity |

## Security Baseline (must-have in this environment)
- LDAP signing: Required on all DCs (Event 2886 = unsigned bind detected)
- LDAP channel binding: Enabled
- SMB signing: Required on all DCs
- Kerberos: AES256 only (RC4 disabled where possible)
- KRBTGT: Reset every 180 days (twice, 10 hours apart)
- Unconstrained delegation: Disabled everywhere
- AdminSDHolder: Reviewed quarterly
- PCI forest trust: One-way only — verified via `Get-ADTrust -Filter *`

## Diagnostic Commands (copy-paste ready)
```powershell
# Account status full dump
Get-ADUser -Identity [username] -Properties PasswordLastSet,LastLogonDate,LockedOut,Enabled,PasswordExpired | Select *

# All members of privileged groups
Get-ADGroupMember "Domain Admins" | Get-ADUser -Properties LastLogonDate,Enabled

# SPNs for a service account (Kerberoasting check)
Get-ADUser -Identity [svcacct] -Properties ServicePrincipalNames | Select -Expand ServicePrincipalNames

# Duplicate SPNs (auth failure cause)
setspn -X -F

# KRBTGT last password set
Get-ADUser krbtgt -Properties PasswordLastSet | Select PasswordLastSet

# Replication health
repadmin /replsummary
repadmin /showrepl * /errorsonly

# ADConnect sync errors (run on ADConnect server)
Get-ADSyncConnectorRunStatus
```

## Vendor Doc Pointer
Raw docs in: vendor-docs-raw/microsoft/
- AD security best practices: MS-AD-Security-Guide.pdf
- Entra ID documentation: [online — docs.microsoft.com/entra]
- ADConnect troubleshooting: MS-ADConnect-TroubleshootingGuide.pdf
