# servicenow.md — Vendor Summary
# Covers: ServiceNow ITSM, CMDB (APM#), ICS IAM team workflows, catalog admin

## Architecture in This Environment
- ServiceNow is the enterprise ITSM platform
- CMDB: Application records use APM# (unique app ID) as primary key
- APM# has: application name, owner (manager), support group — but NO service account mapping (gap)
- ICS IAM team receives: incidents, incident tasks, service requests, change orders, problem records
- Bot provisioning process: triggers ServiceNow ICS IAM ticket for manual RBAC provisioning
- SQLite DB: last 12 months of all IAM tickets exported for local analysis

## Key Table Structure (for db-query and db-analyze.py)
| Table | What it contains | IAM relevance |
|-------|-----------------|--------------|
| incidents | Security and access incidents | Auth failures, compromise, access denials |
| incident_tasks | Sub-tasks of incidents | Pillar-specific work items |
| service_requests | User/team access requests | RBAC provisioning, account requests |
| change_orders | Infrastructure/IAM changes | Change review, CAB preparation |
| problems | Root cause investigation records | Recurring issue tracking |

## CMDB Gap (Critical Finding)
APM# contains app owner but NOT which service accounts are tied to that application.
This creates a NIST CM-8 + NYDFS §500.7 + PCI DSS 8.6 gap.
Finding: IAM service accounts cannot be traced to their owning application via CMDB.
Workaround: manual mapping maintained by PPM team.
Recommendation: ServiceNow CMDB enhancement — add service account relationship field.

## Ticket Patterns for IAM Team
| Ticket type | Common causes | Owning pillar |
|------------|--------------|---------------|
| Account lockout — P1/P2 | Brute force, password spray, sync issue | FID → SecOps |
| Access not provisioned | JML event not triggered, bot process failed | PaLM |
| Service account auth failure | Credential expired, not vaulted, rotation failed | PPM |
| Privilege escalation request | EPM not configured, JIT not deployed | PPM + IAC |
| Access review overdue | Manual process gap, no IG automation | IAC |
| AD replication failure | Network, DC health | FID |

## Catalog Admin Notes
- ICS IAM team manages catalog items for: account provisioning, access requests, RBAC changes
- Self-service items: managed via Specops for password resets (primary accounts only)
- Non-standard requests: route to ICS IAM ticket queue

## Common Queries for CAB Preparation
```sql
-- Changes that caused incidents (last 12 months)
SELECT c.number, c.short_description, COUNT(i.number) as incidents
FROM change_orders c
JOIN incidents i ON i.opened_at BETWEEN c.end_date AND datetime(c.end_date, '+48 hours')
WHERE c.opened_at >= date('now', '-12 months')
GROUP BY c.number HAVING incidents > 0 ORDER BY incidents DESC

-- Open problems with no root cause
SELECT number, short_description, state, opened_at
FROM problems WHERE root_cause IS NULL AND state NOT IN ('Closed','Resolved')
ORDER BY opened_at ASC
```
