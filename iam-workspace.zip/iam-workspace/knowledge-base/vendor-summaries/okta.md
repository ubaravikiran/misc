# okta.md — Vendor Summary
# Covers: Okta SSO, sync agents, MFA, SCIM, app integrations, Okta → Entra migration

## Architecture in This Environment
- Okta syncs users from core AD domains + other domains via separate AD sync agents
- Applications federated using Okta AND Entra (migration in progress to Entra)
- Okta feeds OIG via manual CSV — NOT API (data freshness risk — gap IAM-XXX)
- Okta system log NOT currently forwarded to Google SecOps (detection gap)
- Okta Super Admin scope: owned by FID team

## Integration Points
| Target | Method | Notes |
|--------|--------|-------|
| AD | Sync agents per domain | Not same as ADConnect — separate sync |
| OIG / IG | Manual CSV export | Latency risk — not real-time |
| Applications | SAML / OIDC | Okta as IdP — migration to Entra underway |
| Google SecOps | NOT CONNECTED | Critical gap — Okta auth events blind to SIEM |

## Common Failure Modes
| Symptom | First check | Tool/command |
|---------|------------|--------------|
| Users can't authenticate to Okta app | Is user synced to Okta? Check sync agent status | Okta admin → Directory → Agents |
| Sync agent stopped syncing | Agent service running? Network connectivity? | Okta admin → Agents → check last sync time |
| New user not in Okta | AD account created? Sync agent ran? OU in scope? | Check AD user creation time vs last sync |
| MFA prompt not appearing | MFA policy assigned? User enrolled? | Okta admin → Security → Multifactor |
| SAML assertion failing | Certificate expired? Attribute mapping correct? | Okta app settings → SAML metadata |
| Okta → Entra app migration issue | Federation config in Entra correct? | Entra app registration → SAML settings |

## Key Log Events (Okta System Log)
| Event | Meaning |
|-------|---------|
| user.authentication.auth_via_mfa | Successful MFA |
| user.authentication.sso | App SSO event |
| user.account.lock | Account locked |
| policy.evaluate_sign_on | Sign-on policy evaluated |
| user.session.start | User session created |
| security.threat.detected | Okta ThreatInsight alert |
| user.mfa.factor.deactivate | MFA factor removed |

## Security Baseline
- MFA enabled for all users — no exceptions
- Admin accounts use phishing-resistant MFA (FIDO2 / Okta FastPass)
- Okta system log → SIEM (currently missing — P1 gap)
- Okta API token rotation on schedule
- Network zones configured — block auth from unexpected geographies
- Suspicious activity reporting enabled

## Diagnostic Commands
```
# Check Okta user status via API (requires API token from PAM vault)
curl -X GET "https://[company].okta.com/api/v1/users/[email]"   -H "Authorization: SSWS [token]"   -H "Content-Type: application/json"

# List all active Okta admin users
curl -X GET "https://[company].okta.com/api/v1/users?filter=status+eq+%22ACTIVE%22&search=profile.login+sw+%22admin%22"   -H "Authorization: SSWS [token]"
```
