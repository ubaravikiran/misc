# arcon-pam-epm.md — Vendor Summary
# Covers: Arcon PAM (vault, session brokering, JIT), Arcon EPM (endpoint privilege)

## Arcon PAM Architecture in This Environment
- PAM vault stores service account credentials — application retrieval via REST API
- Session brokering: admin GUI for jump sessions (not yet fully deployed)
- Session recording: configured but deployment coverage not 100%
- JIT elevation: NOT YET DEPLOYED (gap)
- Session management: NOT YET DEPLOYED (gap)
- Credential rotation: configured per account type, rotation policies active
- Rollout status: IN PROGRESS — some apps still use static credentials

## Arcon EPM Architecture
- Manages local admin rights on endpoints
- Time-bound elevation via approval workflow
- Application whitelisting per machine class
- Coverage: Windows domain-joined workstations (primary coverage) — Autopilot, MacOS, non-domain-joined are gaps

## Common Failure Modes — PAM
| Symptom | First check | Command |
|---------|------------|---------|
| App can't retrieve credential from vault | API token valid? Service account enrolled? | Arcon PAM admin → Accounts → check enrollment |
| Service account password expired despite PAM | Rotation schedule ran? AD sync? | Arcon PAM → Account → rotation history |
| Admin can't reach jump target | Session broker running? Target server responsive? | Arcon PAM → Sessions → active sessions log |
| PAM API returning 401 | API token expired? Account locked in PAM? | Arcon PAM admin → API token management |

## Common Failure Modes — EPM
| Symptom | First check | Action |
|---------|------------|--------|
| User can't elevate application | EPM agent running? App in whitelist? | Arcon EPM admin → Check agent + elevation policy |
| EPM agent not checking in | Network connectivity? Agent service status? | `services.msc` → Arcon EPM Agent service status |
| Elevation approved but process still blocked | UAC conflict? Policy applied? | Check Windows Event Log for EPM policy events |
| Local admin removal caused application break | App requires local admin? | Arcon EPM → Application whitelist → add app with elevation rule |

## Key Log Events
| Location | Event | Meaning |
|----------|-------|---------|
| Arcon PAM | Credential checkout | Service account credential retrieved |
| Arcon PAM | Session initiated | Admin jump session started |
| Arcon PAM | Password rotated | Credential rotation executed |
| Arcon EPM | Elevation approved | Local admin granted time-bound |
| Arcon EPM | Elevation blocked | Process blocked by EPM policy |
| Arcon EPM | Agent offline | Endpoint not reporting |

## Security Baseline
- All service accounts enrolled in PAM vault — no standalone passwords
- Programmatic retrieval via PAM API only — no hardcoded credentials
- Session recording enabled for all privileged sessions
- PAM vault access limited to account owners + PAM admins
- EPM agent deployed on all domain-joined Windows machines
- Elevation requires approval for admin-level requests
- PAM service account (used by IG fulfillers) scoped to minimum required permissions

## PAM API Credential Retrieval Pattern
```powershell
# Retrieve credential from Arcon PAM vault (PowerShell)
$headers = @{ "Authorization" = "Bearer $(op read 'op://VAULT/Arcon-PAM/api-token')" }
$response = Invoke-RestMethod -Uri "https://[arcon-pam-url]/api/account/credentials" `
    -Headers $headers -Method GET -Body @{ accountName = "[service-account-name]" }
$password = $response.password
```
