# Identity Governance — Assessment Pillar
# Tools: OpenText Identity Governance (IG), NetIQ, PowerShell fulfillers

## Current State Context
IG is in production but NOT enterprise-functional. Performance and functionality
issues prevent enterprise rollout. Currently piloted to IAM department with RBAC only.
Access reviews, SoD enforcement, and certifications are manual.
Working with Opentext Professional Services — progress blocked.
Leadership decision on path (fix vs replace) is pending.

## Checklist

### IG Platform Status
| # | Control | NIST | NYDFS | Evidence | Pass criteria |
|---|---------|------|-------|----------|---------------|
| IG-001 | IG production status documented | AC-2 | §500.7 | Gap register + PS engagement log | Formal documentation of current limitations |
| IG-002 | IG RBAC pilot scope documented | AC-3 | §500.7 | IG admin — enrolled users | IAM dept pilot documented with scope |
| IG-003 | IG API collectors operational (AD/Entra) | CM-6 | §500.3 | IG collector log | Last successful collection timestamp < 24h |
| IG-004 | Okta manual CSV feed — risk documented | SI-12 | §500.7 | Gap register | Data freshness risk formally documented |
| IG-005 | Leadership decision on IG path documented | AC-2 | §500.7 | Steering committee record | Decision status documented (pending/decided) |

### Access Reviews (currently manual)
| # | Control | NIST | NYDFS | Evidence | Pass criteria |
|---|---------|------|-------|----------|---------------|
| IG-006 | Access review process documented | AC-2 | §500.7 | Process document | Manual review process with cadence defined |
| IG-007 | Access review cadence compliant | AC-2 | §500.7 | Review records | Review completed within required period |
| IG-008 | Access review evidence preserved for audit | AC-2 | §500.7 | Completed review artifacts | Signed-off reviews stored in Confluence/SharePoint |
| IG-009 | Privileged account access review separate cadence | AC-2(7) | §500.7 | Review records | More frequent review for privileged accounts |

### SoD (currently manual)
| # | Control | NIST | NYDFS | Evidence | Pass criteria |
|---|---------|------|-------|----------|---------------|
| IG-010 | SoD ruleset documented | AC-5 | §500.7 | SoD matrix document | Conflicting roles defined and documented |
| IG-011 | SoD check process for new access requests | AC-5 | §500.7 | Process document | Manual SoD check on every access request |
| IG-012 | Existing SoD violations inventoried | AC-5 | §500.7 | SoD violation register | Known violations documented with risk acceptance |

### IG Fulfiller Scripts (SDLC gap)
| # | Control | NIST | NYDFS | Evidence | Pass criteria |
|---|---------|------|-------|----------|---------------|
| IG-013 | Fulfiller scripts in source control | SA-3 | §500.14 | Git repository reference | All scripts versioned in git (currently a gap) |
| IG-014 | Fulfiller scripts have peer review record | SA-11 | §500.14 | Code review records | Every script change reviewed (gap) |
| IG-015 | Fulfiller service account scope minimized | AC-6 | §500.7 | AD rights of fulfiller SA | Least privilege applied |
| IG-016 | Fulfiller script change control process | CM-3 | §500.14 | Change record | CAB approval for fulfiller changes (gap) |

## Scoring guide
Level 1: IG deployed but unusable, no documented reviews, SoD undefined, fulfiller scripts ungoverned.
Level 2: IG pilot active, manual review process documented, SoD rules defined.
Level 3: Manual reviews consistently executed with evidence, SoD violations tracked, fulfiller scripts in source control.
Level 4: IG enterprise-functional, automated certifications, SoD automated in IG.
Level 5: Continuous access intelligence, predictive role management, real-time SoD enforcement.
