# PAM — Assessment Pillar
# Tools: Arcon PAM, Arcon EPM, Specops, 1Password

## Checklist

### Service Account Governance
| # | Control | NIST | NYDFS | PCI | Evidence | Pass criteria |
|---|---------|------|-------|-----|----------|---------------|
| PAM-001 | Service account inventory complete | AC-2 | §500.7 | PCI 8.6 | `Get-ADServiceAccount -Filter * ; Get-ADUser -Filter {ServicePrincipalName -like "*"}` | All SAs documented with app owner |
| PAM-002 | Service account → application mapping in CMDB | CM-8 | §500.7 | PCI 8.6 | ServiceNow CMDB query — SA linked to APM# | All SAs linked to APM# (currently a gap) |
| PAM-003 | All service accounts enrolled in Arcon PAM vault | AC-2(7) | §500.7 | PCI 8.6 | Arcon PAM vault export vs AD SA inventory | 100% enrollment (identify gap count) |
| PAM-004 | Interactive service accounts have rotation policy | IA-5 | §500.7 | PCI 8.6 | Arcon PAM rotation schedule export | All interactive SAs have defined rotation |
| PAM-005 | gMSA used wherever interactive SA can be replaced | AC-6 | §500.7 | | `Get-ADServiceAccount -Filter * -Properties Description` | gMSA adoption rate documented |
| PAM-006 | RPA accounts have governance records | AC-2 | §500.7 | PCI 8.6 | RPA account inventory | Review/rotation process defined |

### Arcon PAM
| # | Control | NIST | NYDFS | Evidence | Pass criteria |
|---|---------|------|-------|----------|---------------|
| PAM-007 | PAM vault coverage — quantified | AC-2(7) | §500.7 | Vault export count vs SA total | % enrolled documented |
| PAM-008 | Programmatic credential retrieval via PAM API | IA-5(7) | §500.7 | App integration audit | No hardcoded credentials in integrations |
| PAM-009 | Session recording deployment status | AU-2 | §500.6 | Arcon PAM session config | Session recording enabled for privileged sessions |
| PAM-010 | Session recording retention ≥ 1 year | AU-11 | §500.6 | Arcon PAM retention config | Retention policy ≥ 365 days |
| PAM-011 | JIT elevation — deployment status documented | AC-6 | §500.7 | Deployment tracker | JIT not yet deployed — documented as gap |

### Arcon EPM
| # | Control | NIST | NYDFS | Evidence | Pass criteria |
|---|---------|------|-------|----------|---------------|
| PAM-012 | EPM coverage — Windows domain workstations | AC-6 | §500.7 | EPM admin — enrolled machine count | Coverage % documented |
| PAM-013 | EPM coverage — Windows Autopilot machines | AC-6 | §500.7 | EPM + Intune enrollment comparison | Coverage gap quantified |
| PAM-014 | EPM coverage — MacOS workstations | AC-6 | §500.7 | EPM admin — macOS agent deployment | Coverage % or gap documented |
| PAM-015 | EPM coverage — Windows non-domain-joined | AC-6 | §500.7 | EPM admin vs AD computer objects | Gap documented |
| PAM-016 | Local admin removal verified for covered machines | AC-6 | §500.7 | EPM + `net localgroup administrators` spot check | No persistent local admin outside EPM |

## Scoring guide
Level 1: No SA inventory, no vault, EPM partially deployed.
Level 2: SA inventory exists, partial vault enrollment, EPM on some machines.
Level 3: SA inventory complete, vault > 80% enrolled, EPM on all domain-joined machines.
Level 4: Full vault enrollment, programmatic retrieval in use, session recording active.
Level 5: JIT deployed, continuous NHI governance, automated rotation.
