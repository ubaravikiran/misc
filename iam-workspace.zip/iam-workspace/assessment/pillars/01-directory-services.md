# Directory Services — Assessment Pillar
# Tools: AD (multi-forest/domain), Entra ID, ADConnect, RadiantLogic, GroupID

## Scope
AD forests: AM core, HS core, MS core, PCI (one-way trust), DMZ.
Entra ID: hybrid identity via ADConnect.
RadiantLogic VDS: identity aggregation.
GroupID: AD group lifecycle.

## Checklist

### AD Infrastructure
| # | Control | NIST | NYDFS | Evidence command | Pass criteria |
|---|---------|------|-------|-----------------|---------------|
| DS-001 | LDAP signing enforced on all DCs | CM-6 | §500.3 | `Get-ADDomainController -Filter * | Get-ItemProperty -Path "HKLM:\System\CurrentControlSet\Services\NTDS\Parameters" -Name "LDAPServerIntegrity"` | Value = 2 on all DCs |
| DS-002 | LDAP channel binding enforced | CM-6 | §500.3 | Event ID 2886/2887 absent in DC logs | No unsigned bind warnings |
| DS-003 | KRBTGT password reset within 180 days | IA-5 | §500.7 | `Get-ADUser krbtgt -Properties PasswordLastSet` | PasswordLastSet < 180 days ago |
| DS-004 | AdminSDHolder reviewed quarterly | AC-6 | §500.7 | `Get-ADUser -Filter {AdminCount -eq 1} -Properties AdminCount,LastLogonDate` | All accounts active + justified |
| DS-005 | Unconstrained delegation disabled | AC-6 | §500.7 | `Get-ADComputer -Filter {TrustedForDelegation -eq $true}` | Only DCs return — no workstations/servers |
| DS-006 | PCI forest one-way trust verified | AC-4 | PCI 7.2 | `Get-ADTrust -Filter * -Server [AM-DC]` | PCI trusts Corp — NOT Corp trusts PCI |
| DS-007 | Stale accounts (90+ day inactive) | AC-2(3) | §500.7 | `Search-ADAccount -AccountInactive -TimeSpan 90:00:00:00 -UsersOnly` | Count documented, remediation planned |
| DS-008 | Privileged groups membership documented | AC-2(7) | §500.7 | `Get-ADGroupMember "Domain Admins","Schema Admins","Enterprise Admins" -Recursive` | No service accounts, no stale accounts |
| DS-009 | AD replication health verified | CM-6 | §500.3 | `repadmin /replsummary` | 0 errors, last sync < 1 hour |
| DS-010 | Sites and Services topology documented | CM-8 | §500.3 | `Get-ADReplicationSite -Filter *` | All DCs in correct site |

### Entra ID / ADConnect
| # | Control | NIST | NYDFS | Evidence command | Pass criteria |
|---|---------|------|-------|-----------------|---------------|
| DS-011 | ADConnect sync errors reviewed | SI-12 | §500.3 | Entra Connect Health portal export | 0 unresolved sync errors |
| DS-012 | ADConnect staging server exists | CM-6 | §500.3 | Get-ADSyncConnectorRunStatus on staging server | Staging server in place |
| DS-013 | Password hash sync or PTA configured | IA-2 | §500.12 | Entra admin center — Authentication method | PHS or PTA active |
| DS-014 | Hybrid join device compliance policy | IA-2(2) | §500.12 | Entra CA policy export | Compliant device required for non-MFA fallback |

### RadiantLogic
| # | Control | NIST | NYDFS | Evidence command | Pass criteria |
|---|---------|------|-------|-----------------|---------------|
| DS-015 | RadiantLogic access control documented | AC-3 | §500.7 | RadiantLogic VDS access log | Only authorized consumers in LDAP ACL |
| DS-016 | PII attributes in VDS classified | RA-2 | §500.13 | VDS schema review — flagged PII fields | Classification label applied |

### Ghost Accounts (AM OpCo — HS/MS users)
| # | Control | NIST | NYDFS | Evidence command | Pass criteria |
|---|---------|------|-------|-----------------|---------------|
| DS-017 | Ghost account lifecycle process documented | AC-2 | §500.7 | Process document reference | Written process with owner |
| DS-018 | afiExternalUserID correlation validated | IA-4 | §500.7 | `Get-ADUser -Filter * -SearchBase [OU] -Properties afiExternalUserID | Where {$_.afiExternalUserID -eq $null}` | 0 ghost accounts with null key |

## Scoring guide
Level 1: DS-001 to DS-010 mostly FAIL, no documentation.
Level 2: DS-001 to DS-010 partially PASS, some documentation.
Level 3: DS-001 to DS-014 PASS with evidence, ghost account process documented.
Level 4: All items PASS with evidence, metrics tracked.
Level 5: Automated drift detection, continuous monitoring.
