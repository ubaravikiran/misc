# Identity Administration — Assessment Pillar
# Tools: NetIQ/MyAccess, Workday, Simplify, PMAC

## Checklist

### JML Process
| # | Control | NIST | NYDFS | Evidence | Pass criteria |
|---|---------|------|-------|----------|---------------|
| IA-001 | Joiner process documented for all HR sources | PS-2 | §500.7 | Process document — Workday/Simplify/PMAC | Three separate documented processes |
| IA-002 | Mover process documented | PS-5 | §500.7 | Process document | Role change → access update process documented |
| IA-003 | Leaver process documented — timely disable | PS-4 | §500.7 | Process document + SLA definition | Same-day disable on termination |
| IA-004 | Leaver SLA compliance — sample test | PS-4 | §500.7 | NetIQ log — termination date vs disable date | No accounts active > 24h post-termination |
| IA-005 | Rebadge process documented — 30-day overlap risk | AC-2 | §500.7 | Process document | Old account entitlement freeze during overlap documented |

### NetIQ / MyAccess
| # | Control | NIST | NYDFS | Evidence | Pass criteria |
|---|---------|------|-------|----------|---------------|
| IA-006 | NetIQ scope limitation documented | AC-2 | §500.7 | Gap register | Primary accounts only — all other types documented as gaps |
| IA-007 | NetIQ provisioning log reviewed | AU-6 | §500.7 | NetIQ admin — provisioning report | Regular review cadence documented |
| IA-008 | Exchange mailbox creation automated | AC-2(1) | §500.7 | NetIQ workflow — mailbox task | Automated for primary accounts |
| IA-009 | Entra license assignment automated | AC-2(1) | §500.7 | NetIQ workflow — Entra license task | Automated for primary accounts |
| IA-010 | eDirectory synchronization health | CM-6 | §500.3 | NetIQ sync status | No sync errors, replication current |

### Secondary, Ghost, NHI Account Lifecycle
| # | Control | NIST | NYDFS | Evidence | Pass criteria |
|---|---------|------|-------|----------|---------------|
| IA-011 | Secondary account de-provisioning process | AC-2 | §500.7 | Process document | Manual process documented with owner |
| IA-012 | Ghost account de-provisioning process | AC-2 | §500.7 | Process document | Manual process documented with owner |
| IA-013 | Vendor/contractor de-provisioning at contract end | PS-4 | §500.7 | Simplify offboarding SLA | SLA defined or gap documented |

### Birthright Provisioning
| # | Control | NIST | NYDFS | Evidence | Pass criteria |
|---|---------|------|-------|----------|---------------|
| IA-014 | ModelID-based provisioning process documented | AC-2 | §500.7 | Bot process documentation | RBAC assignment via ServiceNow ICS IAM ticket documented |
| IA-015 | Bot process ServiceNow ticket SLA defined | AC-2 | §500.7 | ServiceNow SLA config | Response/resolution SLA for ICS IAM tickets defined |

## Scoring guide
Level 1: JML mostly manual, no documented SLAs, scope gaps unacknowledged.
Level 2: JML documented for primary accounts, SLAs partially defined.
Level 3: All JML documented, SLAs measured, secondary/ghost gaps in gap register.
Level 4: JML SLAs met consistently, metrics tracked, automation expanding.
Level 5: Full lifecycle automation for all account types including secondary and NHI.
