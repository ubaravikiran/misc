# Access Management — Assessment Pillar
# Tools: Okta, SiteMinder, Conditional Access, Specops, Silverfort

## Checklist

### Conditional Access / MFA
| # | Control | NIST | NYDFS | Evidence command/action | Pass criteria |
|---|---------|------|-------|------------------------|---------------|
| AM-001 | MFA enforced for all privileged accounts | IA-2(1) | §500.12 | Export CA policies from Entra — filter by admin roles | All privileged roles require MFA |
| AM-002 | MFA enforced for all non-privileged users | IA-2(2) | §500.12 | CA policy export — baseline MFA policy | No user can authenticate without MFA |
| AM-003 | Phishing-resistant MFA for admin accounts | IA-2(1) | §500.12 | CA policy export — authentication strength | FIDO2 or certificate-based auth for admins |
| AM-004 | Non-domain-joined machine policy documented | IA-2 | §500.7 | CA policy — device filter | Autopilot + non-domain-joined in scope |
| AM-005 | PCI forest MFA coverage evidenced | IA-2(1) | PCI 8.4 | Arcon PAM + CA policy for PCI scope | MFA at every access point to PCI forest |

### Okta
| # | Control | NIST | NYDFS | Evidence command/action | Pass criteria |
|---|---------|------|-------|------------------------|---------------|
| AM-006 | Okta system log forwarded to Google SecOps | AU-12 | §500.14 | Google SecOps — Okta log source status | Okta logs in SIEM (currently a gap) |
| AM-007 | Okta → Entra migration status documented | CM-6 | §500.3 | Migration tracker / roadmap reference | Migration plan exists with timeline |
| AM-008 | Okta manual CSV feed to IG documented as risk | SI-12 | §500.3 | Gap register entry | IAM gap finding documented |
| AM-009 | Okta dormant user accounts reviewed | AC-2(3) | §500.7 | Okta system log — last login 90+ days | Review completed, remediation in progress |

### Specops
| # | Control | NIST | NYDFS | Evidence command/action | Pass criteria |
|---|---------|------|-------|------------------------|---------------|
| AM-010 | Password complexity policy enforced — primary accounts | IA-5 | §500.7 | Specops policy export | Policy enforced, breach detection active |
| AM-011 | Specops scope limitation documented | IA-5 | §500.7 | Gap register entry | Secondary/ghost/NHI accounts gap documented |

### Silverfort
| # | Control | NIST | NYDFS | Evidence command/action | Pass criteria |
|---|---------|------|-------|------------------------|---------------|
| AM-012 | Silverfort auth monitoring scope covers all forests | SI-4 | §500.14 | Silverfort admin — covered domains list | All core domains in scope |
| AM-013 | Silverfort alerts forwarded to SIEM | AU-12 | §500.14 | Google SecOps — Silverfort log source | Silverfort events in SIEM |
| AM-014 | Non-domain-joined server coverage gap documented | AC-17 | §500.7 | Gap register entry | Gap formally documented |

## Scoring guide
Level 1: MFA gaps, no CA baseline, Okta not in SIEM.
Level 2: MFA for most users, CA documented, gaps identified.
Level 3: MFA universal, CA policies documented and evidenced, all gaps in gap register.
Level 4: Phishing-resistant MFA for admins, Okta in SIEM, metrics tracked.
Level 5: Continuous auth risk scoring, automated anomaly response.
