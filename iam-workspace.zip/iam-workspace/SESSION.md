# SESSION.md — Edit before every Claude Code session (10 seconds)
# Claude reads this first and loads ONLY what is listed below.

---

## YOU EDIT THESE 4 LINES:

MODE:      [ daily-ops | assessment | knowledge-build ]
TASK:      < one sentence describing what you're doing >
AUDIENCE:  < who will receive the output >
OUTPUT:    < what you need Claude to produce >

---

## EXAMPLES — copy and edit:

# Escalation troubleshooting
# MODE:     daily-ops
# TASK:     Okta AD agent sync failure escalated from SecOps — users cannot authenticate
# AUDIENCE: SecOps lead, server team, my director
# OUTPUT:   Tactical fix steps, RCA draft, ServiceNow P1 update, reg gap citation

# Assessment pillar work
# MODE:     assessment
# TASK:     Run PAM pillar assessment — Arcon PAM checklist with evidence from arcon-export.csv
# AUDIENCE: Principals and leadership
# OUTPUT:   Findings in standard format, gap register entries, Confluence page draft

# Consultation prep
# MODE:     daily-ops
# TASK:     Prepare IAM position for CAB meeting — new app onboarding requesting service account
# AUDIENCE: Change Advisory Board, application developers, enterprise architects
# OUTPUT:   CAB talking points, IAM requirements checklist, risk statement

# Knowledge build (one-time)
# MODE:     knowledge-build
# TASK:     Digest NYDFS Part 500 PDF — extract IAM-relevant sections only
# AUDIENCE: Internal reference
# OUTPUT:   Append to QUICK-REF.md Section 2

---

## LOAD RULES (Claude follows these automatically based on MODE):

### daily-ops
Always load:   CONTEXT.md, QUICK-REF.md
Load if exist: daily-ops/runbooks/<relevant-tool>.md
               daily-ops/consultation-templates/<relevant-team>.md
               daily-ops/itil/<incident|problem|change>.md
Never load:    assessment/evidence/, knowledge-base/regs-raw/, vendor-docs-raw/

### assessment
Always load:   CONTEXT.md, QUICK-REF.md, FINDING_FORMAT.md
Load if exist: assessment/pillars/<relevant-pillar>.md
               assessment/gap-register.md (summary only — last 20 entries)
Never load:    knowledge-base/regs-raw/, vendor-docs-raw/, other pillars

### knowledge-build
Load:          Only the specific raw file named in TASK
Output to:     QUICK-REF.md or vendor-summaries/<tool>.md
Never load:    CONTEXT.md, assessment/, daily-ops/

---

## SESSION OPENER (paste this into Claude Code after editing above):

Read SESSION.md. Load only the files specified for this MODE.
Do not load anything else unless I explicitly ask.
My task: [copy your TASK line here]
