#!/usr/bin/env python3
"""
db-setup.py — Run this once to validate your ServiceNow SQLite DB
and generate the schema cache that Claude Code uses.

Usage: python3 db-setup.py [path-to-db]
Default path: data/iam-servicenow.db
"""

import sqlite3
import json
import sys
import os
from datetime import datetime

DB_PATH = sys.argv[1] if len(sys.argv) > 1 else "data/iam-servicenow.db"

def validate_and_describe(db_path):
    if not os.path.exists(db_path):
        print(f"❌ DB not found at: {db_path}")
        print(f"   Place your ServiceNow export at {db_path} or pass the path as argument.")
        return

    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    print(f"✅ Connected to: {db_path}")
    print(f"   Size: {os.path.getsize(db_path) / 1024 / 1024:.1f} MB\n")

    # Get all tables
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")
    tables = [row[0] for row in cursor.fetchall()]
    print(f"Tables found: {tables}\n")

    schema = {}
    for table in tables:
        cursor.execute(f"PRAGMA table_info({table})")
        columns = cursor.fetchall()
        cursor.execute(f"SELECT COUNT(*) FROM {table}")
        count = cursor.fetchone()[0]

        schema[table] = {
            "row_count": count,
            "columns": [{"cid": c[0], "name": c[1], "type": c[2], "notnull": c[3]} for c in columns]
        }

        print(f"📋 {table}: {count:,} rows")
        print(f"   Columns: {', '.join([c[1] for c in columns])}")

        # Date range check
        date_cols = [c[1] for c in columns if 'date' in c[1].lower() or 'opened' in c[1].lower() or 'created' in c[1].lower()]
        if date_cols:
            try:
                cursor.execute(f"SELECT MIN({date_cols[0]}), MAX({date_cols[0]}) FROM {table}")
                min_d, max_d = cursor.fetchone()
                print(f"   Date range ({date_cols[0]}): {min_d} → {max_d}")
            except:
                pass
        print()

    # Save schema cache for Claude Code
    schema_path = "data/db-schema-cache.json"
    os.makedirs("data", exist_ok=True)
    with open(schema_path, 'w') as f:
        json.dump({
            "db_path": db_path,
            "generated": datetime.now().isoformat(),
            "tables": schema
        }, f, indent=2)
    print(f"✅ Schema cache saved to {schema_path}")
    print(f"   Claude Code will use this in every CAB and DB session.\n")

    # Quick health checks
    print("=== QUICK HEALTH CHECKS ===")

    # P1/P2 incidents last 12 months
    for table in tables:
        col_names = [c["name"] for c in schema[table]["columns"]]
        if 'priority' in col_names:
            try:
                date_col = next((c for c in ['opened_at','created_at','sys_created_on'] if c in col_names), None)
                if date_col:
                    cursor.execute(f"""
                        SELECT priority, COUNT(*) as cnt FROM {table}
                        WHERE {date_col} >= date('now','-12 months')
                        GROUP BY priority ORDER BY priority
                    """)
                    rows = cursor.fetchall()
                    if rows:
                        print(f"\n{table} by priority (last 12mo):")
                        for r in rows:
                            print(f"  P{r[0]}: {r[1]:,} records")
            except Exception as e:
                pass

    conn.close()
    print("\n✅ DB setup complete. Ready for /cab and /db-query commands.")
    print(f"\nAdd to SESSION.md or CLAUDE.md:\n  DB_PATH={db_path}")

if __name__ == "__main__":
    validate_and_describe(DB_PATH)
