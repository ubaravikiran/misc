#!/usr/bin/env python3
"""
db-analyze.py — Analyze ServiceNow SQLite DB and store insights as new tables.
Data NEVER leaves the DB. No files written except INSIGHTS-INDEX.md (no ticket data).

Run: python3 data/db-analyze.py [path-to-db]
Default: data/iam-servicenow.db

Creates 5 iam_* tables in the SAME database:
  iam_insights        — recurring incident patterns with counts + sample ticket IDs
  iam_change_risks    — changes that caused incidents within 48hrs
  iam_p1p2_index      — P1/P2 incident index with pattern tags
  iam_open_problems   — open problems with no root cause
  iam_team_activity   — team change volume + risk ratio
"""

import sqlite3, sys, os
from datetime import datetime
from collections import defaultdict

DB_PATH = sys.argv[1] if len(sys.argv) > 1 else "data/iam-servicenow.db"
INDEX   = "data/INSIGHTS-INDEX.md"   # tiny file — no ticket data

# ── IAM keyword → pattern name mapping ───────────────────────────────────────
PATTERNS = {
    'Okta / SSO':           ['okta','sso','saml','oidc','federation','siteminder'],
    'AD / Kerberos':        ['kerberos','kdc','active directory','domain controller','ldap','replication','gpo','group policy'],
    'Entra / Azure AD':     ['entra','azure ad','conditional access','intune','adconnect','aad'],
    'Arcon PAM':            ['arcon pam','pam vault','privileged access','session recording'],
    'Arcon EPM':            ['arcon epm','epm','elevation','local admin','endpoint privilege'],
    'NetIQ / MyAccess':     ['netiq','myaccess','provisioning','deprovisioning','joiner','mover','leaver','jml'],
    'IG / RBAC':            ['identity governance','rbac','role based','access review','certification','sod','segregation'],
    'Specops / Password':   ['specops','password reset','password policy','breach password'],
    'Silverfort / MFA':     ['silverfort','mfa','multi-factor','authenticator','push notification'],
    'AD Sync / Hybrid':     ['adconnect','sync agent','attribute sync','hybrid'],
    'Service Account / NHI':['service account','gmsa','rpa account','non-human','nhi','managed identity'],
    'Access / Permission':  ['access denied','permission denied','unauthorized','entitlement','role assignment'],
    'Account Lockout':      ['locked out','lockout','account locked','too many'],
    'Certificate / PKI':    ['certificate','cert expired','keyfactor','pki','ssl','tls','signing cert'],
    'GroupID / Groups':     ['groupid','distribution list','security group','dynamic group','group membership'],
    'RadiantLogic / VDS':   ['radiantlogic','radiantone','vds','virtual directory'],
    'Silverfort Auth':      ['auth anomaly','anomalous auth','auth alert','silverfort alert'],
}

def connect(path):
    if not os.path.exists(path):
        raise FileNotFoundError(f"DB not found: {path}\nRun: python3 data/db-setup.py first.")
    return sqlite3.connect(path)

def get_schema(conn):
    cur = conn.cursor()
    cur.execute("SELECT name FROM sqlite_master WHERE type='table'")
    tables = [r[0] for r in cur.fetchall()]
    cols = {}
    for t in tables:
        cur.execute(f"PRAGMA table_info({t})")
        cols[t] = [r[1] for r in cur.fetchall()]
    return tables, cols

def col(available, candidates):
    for c in candidates:
        if c in available:
            return c
    return None

def safe_q(conn, sql):
    try:
        cur = conn.cursor()
        cur.execute(sql)
        return cur.fetchall()
    except Exception as e:
        print(f"  ⚠  Skipped: {e}")
        return []

def classify(text):
    t = str(text or '').lower()
    for pattern, keywords in PATTERNS.items():
        if any(k in t for k in keywords):
            return pattern
    return 'Other'

# ── CREATE insight tables ─────────────────────────────────────────────────────
def create_tables(conn):
    cur = conn.cursor()
    stmts = [
        """CREATE TABLE IF NOT EXISTS iam_insights (
            id             INTEGER PRIMARY KEY AUTOINCREMENT,
            pattern_name   TEXT NOT NULL,
            incident_count INTEGER NOT NULL,
            sample_tickets TEXT,
            highest_priority TEXT,
            last_analyzed  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""",
        """CREATE TABLE IF NOT EXISTS iam_change_risks (
            id             INTEGER PRIMARY KEY AUTOINCREMENT,
            change_number  TEXT NOT NULL,
            change_desc    TEXT,
            incident_count INTEGER,
            incident_list  TEXT,
            change_team    TEXT,
            last_analyzed  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""",
        """CREATE TABLE IF NOT EXISTS iam_p1p2_index (
            id             INTEGER PRIMARY KEY AUTOINCREMENT,
            incident_number TEXT NOT NULL,
            short_desc     TEXT,
            opened_at      TEXT,
            priority       TEXT,
            pattern_tag    TEXT,
            last_analyzed  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""",
        """CREATE TABLE IF NOT EXISTS iam_open_problems (
            id             INTEGER PRIMARY KEY AUTOINCREMENT,
            problem_number TEXT NOT NULL,
            short_desc     TEXT,
            state          TEXT,
            opened_at      TEXT,
            days_open      INTEGER,
            last_analyzed  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""",
        """CREATE TABLE IF NOT EXISTS iam_team_activity (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            team_name       TEXT NOT NULL,
            change_count    INTEGER,
            incident_caused INTEGER DEFAULT 0,
            risk_ratio      REAL,
            last_analyzed   TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""",
    ]
    for s in stmts:
        cur.execute(s)
    conn.commit()
    print("✅ iam_* tables created / verified")

def clear_tables(conn):
    cur = conn.cursor()
    for t in ['iam_insights','iam_change_risks','iam_p1p2_index','iam_open_problems','iam_team_activity']:
        cur.execute(f"DELETE FROM {t}")
    conn.commit()

# ── POPULATE iam_insights ─────────────────────────────────────────────────────
def populate_insights(conn, tables, cols):
    if 'incidents' not in tables:
        print("  ⚠  No 'incidents' table — skipping iam_insights")
        return {}

    c = cols['incidents']
    date_col = col(c, ['opened_at','created_at','sys_created_on'])
    desc_col = col(c, ['short_description','description','title'])
    num_col  = col(c, ['number','sys_id','id'])
    pri_col  = col(c, ['priority','severity'])

    if not (date_col and desc_col and num_col):
        print("  ⚠  incidents table missing expected columns — skipping iam_insights")
        return {}

    rows = safe_q(conn, f"""
        SELECT {desc_col}, {num_col}, {pri_col or 'NULL'}
        FROM incidents
        WHERE {date_col} >= date('now','-12 months')
    """)

    buckets = defaultdict(list)
    for row in rows:
        p = classify(row[0])
        buckets[p].append({'num': row[1], 'pri': row[2]})

    cur = conn.cursor()
    for pattern, items in sorted(buckets.items(), key=lambda x: -len(x[1])):
        sample_nums = ', '.join([i['num'] for i in items[:5] if i['num']])
        priorities  = [i['pri'] for i in items if i['pri']]
        top_pri     = sorted(set(str(p) for p in priorities if p))[0] if priorities else None
        cur.execute("""
            INSERT INTO iam_insights (pattern_name, incident_count, sample_tickets, highest_priority)
            VALUES (?, ?, ?, ?)
        """, (pattern, len(items), sample_nums, top_pri))

    conn.commit()
    print(f"✅ iam_insights: {len(buckets)} patterns from {len(rows)} incidents")
    return buckets

# ── POPULATE iam_change_risks ─────────────────────────────────────────────────
def populate_change_risks(conn, tables, cols):
    if 'change_orders' not in tables or 'incidents' not in tables:
        print("  ⚠  Missing change_orders or incidents — skipping iam_change_risks")
        return

    cc = cols['change_orders']
    ic = cols['incidents']

    ch_num  = col(cc, ['number','sys_id'])
    ch_desc = col(cc, ['short_description','description'])
    ch_date = col(cc, ['end_date','close_date','completed_date','opened_at'])
    ch_team = col(cc, ['assignment_group','requested_by','u_team'])
    in_num  = col(ic, ['number','sys_id'])
    in_date = col(ic, ['opened_at','created_at'])

    if not (ch_num and ch_date and in_num and in_date):
        print("  ⚠  change/incident tables missing date columns — skipping iam_change_risks")
        return

    rows = safe_q(conn, f"""
        SELECT c.{ch_num}, c.{ch_desc or "'N/A'"},
               {f"c.{ch_team}" if ch_team else "'Unknown'"},
               COUNT(i.{in_num}) as inc_count,
               GROUP_CONCAT(i.{in_num}, ', ') as inc_list
        FROM change_orders c
        LEFT JOIN incidents i
               ON i.{in_date} BETWEEN c.{ch_date}
                  AND datetime(c.{ch_date}, '+48 hours')
        WHERE c.{ch_date} >= date('now','-12 months')
        GROUP BY c.{ch_num}
        HAVING inc_count > 0
        ORDER BY inc_count DESC
        LIMIT 30
    """)

    cur = conn.cursor()
    for row in rows:
        cur.execute("""
            INSERT INTO iam_change_risks (change_number, change_desc, change_team, incident_count, incident_list)
            VALUES (?, ?, ?, ?, ?)
        """, (row[0], str(row[1])[:200] if row[1] else None, row[2], row[3], str(row[4])[:500] if row[4] else None))

    conn.commit()
    print(f"✅ iam_change_risks: {len(rows)} changes linked to incidents")

# ── POPULATE iam_p1p2_index ───────────────────────────────────────────────────
def populate_p1p2(conn, tables, cols):
    if 'incidents' not in tables:
        return

    c = cols['incidents']
    date_col = col(c, ['opened_at','created_at'])
    desc_col = col(c, ['short_description','description'])
    num_col  = col(c, ['number','sys_id'])
    pri_col  = col(c, ['priority','severity'])

    if not (num_col and pri_col and date_col):
        print("  ⚠  incidents missing priority/date columns — skipping iam_p1p2_index")
        return

    rows = safe_q(conn, f"""
        SELECT {num_col}, {desc_col or 'NULL'}, {date_col}, {pri_col}
        FROM incidents
        WHERE {pri_col} IN ('1','2','P1','P2','Critical','High')
        AND {date_col} >= date('now','-12 months')
        ORDER BY {date_col} DESC
        LIMIT 50
    """)

    cur = conn.cursor()
    for row in rows:
        tag = classify(row[1])
        cur.execute("""
            INSERT INTO iam_p1p2_index (incident_number, short_desc, opened_at, priority, pattern_tag)
            VALUES (?, ?, ?, ?, ?)
        """, (row[0], str(row[1])[:200] if row[1] else None, str(row[2])[:20] if row[2] else None, str(row[3]), tag))

    conn.commit()
    print(f"✅ iam_p1p2_index: {len(rows)} P1/P2 incidents indexed")

# ── POPULATE iam_open_problems ────────────────────────────────────────────────
def populate_problems(conn, tables, cols):
    if 'problems' not in tables:
        print("  ⚠  No 'problems' table — skipping iam_open_problems")
        return

    c = cols['problems']
    num_col   = col(c, ['number','sys_id'])
    desc_col  = col(c, ['short_description','description'])
    root_col  = col(c, ['root_cause','cause_code','u_root_cause'])
    state_col = col(c, ['state','status'])
    date_col  = col(c, ['opened_at','created_at','sys_created_on'])

    if not num_col:
        return

    where_root = f"({root_col} IS NULL OR {root_col} = '' OR LOWER({root_col}) IN ('unknown','n/a',''))" if root_col else "1=1"
    where_state = f"AND {state_col} NOT IN ('Closed','Resolved','Cancelled')" if state_col else ""
    date_diff = f", CAST(julianday('now') - julianday({date_col}) AS INTEGER)" if date_col else ", NULL"

    rows = safe_q(conn, f"""
        SELECT {num_col}, {desc_col or 'NULL'}, {state_col or 'NULL'}, {date_col or 'NULL'}{date_diff}
        FROM problems
        WHERE {where_root} {where_state}
        ORDER BY {date_col or num_col} ASC
        LIMIT 30
    """)

    cur = conn.cursor()
    for row in rows:
        cur.execute("""
            INSERT INTO iam_open_problems (problem_number, short_desc, state, opened_at, days_open)
            VALUES (?, ?, ?, ?, ?)
        """, (row[0], str(row[1])[:200] if row[1] else None, str(row[2]) if row[2] else None,
              str(row[3])[:20] if row[3] else None, row[4] if len(row) > 4 else None))

    conn.commit()
    print(f"✅ iam_open_problems: {len(rows)} stale problems found")

# ── POPULATE iam_team_activity ────────────────────────────────────────────────
def populate_team_activity(conn, tables, cols):
    if 'change_orders' not in tables:
        return

    cc = cols['change_orders']
    grp_col  = col(cc, ['assignment_group','requested_by','u_team','opened_by'])
    date_col = col(cc, ['opened_at','sys_created_on'])
    num_col  = col(cc, ['number','sys_id'])

    if not (grp_col and date_col):
        print("  ⚠  change_orders missing group/date columns — skipping iam_team_activity")
        return

    # Total changes per team
    totals = safe_q(conn, f"""
        SELECT {grp_col}, COUNT(*) as cnt
        FROM change_orders
        WHERE {date_col} >= date('now','-12 months')
        GROUP BY {grp_col}
        ORDER BY cnt DESC
        LIMIT 20
    """)

    # Changes that caused incidents — per team
    ic = cols.get('incidents', [])
    in_date = col(ic, ['opened_at','created_at']) if ic else None
    in_num  = col(ic, ['number','sys_id']) if ic else None
    ch_end  = col(cc, ['end_date','close_date','completed_date'])

    team_risks = {}
    if in_date and in_num and ch_end:
        risks = safe_q(conn, f"""
            SELECT c.{grp_col}, COUNT(DISTINCT i.{in_num}) as inc_caused
            FROM change_orders c
            LEFT JOIN incidents i
                   ON i.{in_date} BETWEEN c.{ch_end}
                      AND datetime(c.{ch_end}, '+48 hours')
            WHERE c.{date_col} >= date('now','-12 months')
            GROUP BY c.{grp_col}
        """)
        team_risks = {r[0]: r[1] for r in risks if r[0]}

    cur = conn.cursor()
    for row in totals:
        team  = row[0]
        count = row[1]
        caused = team_risks.get(team, 0)
        ratio  = round(caused / count, 3) if count > 0 else 0.0
        cur.execute("""
            INSERT INTO iam_team_activity (team_name, change_count, incident_caused, risk_ratio)
            VALUES (?, ?, ?, ?)
        """, (str(team)[:100] if team else 'Unknown', count, caused, ratio))

    conn.commit()
    print(f"✅ iam_team_activity: {len(totals)} teams tracked")

# ── WRITE tiny index file (no ticket data) ────────────────────────────────────
def write_index(conn, db_path):
    cur = conn.cursor()
    ts  = datetime.now().strftime("%Y-%m-%d %H:%M")

    top_pattern = "N/A"
    try:
        cur.execute("SELECT pattern_name, incident_count FROM iam_insights ORDER BY incident_count DESC LIMIT 1")
        r = cur.fetchone()
        if r:
            top_pattern = f"{r[0]}: {r[1]} incidents"
    except:
        pass

    table_counts = {}
    for t in ['iam_insights','iam_change_risks','iam_p1p2_index','iam_open_problems','iam_team_activity']:
        try:
            cur.execute(f"SELECT COUNT(*) FROM {t}")
            table_counts[t] = cur.fetchone()[0]
        except:
            table_counts[t] = 0

    content = f"""# INSIGHTS-INDEX.md — Metadata only. No ticket data. Safe to commit.
# Generated: {ts}
# Full data: query iam_* tables in {db_path}

DB_PATH: {db_path}
Last_analyzed: {ts}
Top_pattern: {top_pattern}

Tables:
  iam_insights:       {table_counts.get('iam_insights', 0)} patterns
  iam_change_risks:   {table_counts.get('iam_change_risks', 0)} risky changes
  iam_p1p2_index:     {table_counts.get('iam_p1p2_index', 0)} P1/P2 incidents
  iam_open_problems:  {table_counts.get('iam_open_problems', 0)} stale problems
  iam_team_activity:  {table_counts.get('iam_team_activity', 0)} teams

If tables empty or missing: python3 data/db-analyze.py
"""
    os.makedirs(os.path.dirname(INDEX), exist_ok=True)
    with open(INDEX, 'w') as f:
        f.write(content)
    print(f"✅ INSIGHTS-INDEX.md written (no ticket data — {len(content)} chars)")

# ── MAIN ──────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    print(f"\n{'='*55}")
    print(f"  db-analyze.py — IAM Insights Builder")
    print(f"  DB: {DB_PATH}")
    print(f"{'='*55}\n")

    try:
        conn = connect(DB_PATH)
        tables, cols_map = get_schema(conn)
        print(f"Tables found: {[t for t in tables if not t.startswith('iam_')]}\n")

        create_tables(conn)
        clear_tables(conn)

        print("\nAnalyzing...")
        populate_insights(conn, tables, cols_map)
        populate_change_risks(conn, tables, cols_map)
        populate_p1p2(conn, tables, cols_map)
        populate_problems(conn, tables, cols_map)
        populate_team_activity(conn, tables, cols_map)

        write_index(conn, DB_PATH)
        conn.close()

        print(f"\n{'='*55}")
        print("  Analysis complete. No data left the database.")
        print(f"  Query insights: SELECT * FROM iam_insights ORDER BY incident_count DESC")
        print(f"  Claude Code uses these tables via Python in /debate and /cab sessions")
        print(f"{'='*55}\n")

    except FileNotFoundError as e:
        print(f"\n❌ {e}")
    except Exception as e:
        print(f"\n❌ Failed: {e}")
        raise
