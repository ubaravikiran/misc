# /ref
# Usage: /ref [control ID, regulation section, or plain English topic]
# Instant lookup from QUICK-REF.md. No mode switching needed.
# Examples: /ref AC-6  /ref NYDFS 500.7  /ref MFA privileged accounts  /ref stale accounts

Look up in QUICK-REF.md: $ARGUMENTS

Parse the argument as one of:
- NIST control ID (e.g., AC-6, IA-2(1), AU-12)
- NYDFS section (e.g., §500.7, 500.12)
- PCI DSS requirement (e.g., Req 8.6, Req 7.2)
- Plain English scenario (e.g., "stale accounts", "MFA", "service account rotation")

OUTPUT FORMAT (always brief):
```
## [Control/Section ID] — [Name]

Requirement: [one sentence — what the control requires]
IAM tools: [which tools in our stack implement this]
Enterprise policy: [policy ref if mapped in Section 5]
Our gap status: [from gap-register if known / Unknown if not]

Related controls: [2-3 directly related IDs]
Quick scenario lookup: [from QUICK-REF Section 6 if applicable]
```

If plain English topic: match to Section 6 (scenario lookup) first,
then show all relevant control IDs for that scenario.

This command is designed for use DURING meetings or live troubleshooting —
output must fit on one screen. No paragraphs.
