# /consult
# Usage: /consult [topic, proposal, or question]
# Triggers CONSULT mode. Paste the proposal or question after the command.
# Delivers: bottom line → summary table → red flags → counter-arguments → recommendation

Enter CONSULT mode for the following topic: $ARGUMENTS

Follow the CONSULT output format from CLAUDE.md exactly.

PARALLEL AGENT PROTOCOL:
After delivering the main CONSULT response, list all tools/systems affected by this topic
as "Agent deep-dives available" at the bottom. Do NOT run all agents immediately —
wait for the user to type `agent [toolname]` or `agents-all`.

When `agent [toolname]` is received:
Spawn a focused analysis from that tool's perspective covering:
- Architecture impact (how this change/proposal affects this specific tool)
- Risk (what breaks, what gets exposed, what compliance gap opens)
- Config required (what must change in this tool if the proposal proceeds)
- Evidence to verify (specific log event, config check, or command to confirm)
- Verdict: APPROVE / CONDITIONAL / REJECT from this tool's lens + one-line reason

When `agents-all` is received:
Run ALL relevant agents for the current topic in sequence.
Format each with a clear header. Start with the highest-risk tool first.
End with a consolidated verdict table:
| Tool | Verdict | Key condition |
|------|---------|--------------|

COUNTER-ARGUMENT PROTOCOL:
For every red flag or weakness identified, preemptively construct the pushback
the proposing team will give, then provide the evidence-based counter.
This user is in adversarial consulting environments — they need to win the argument
with facts, not just state a position.
