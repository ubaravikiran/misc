# /safe
# Usage: /safe [topic, proposal, backlog item, or initiative]
# Applies SAFe framing to any work item. Outputs Epic/Feature/Story classification + PI placement.

Apply SAFe framing for: $ARGUMENTS

Load: .claude/agents/special/safe-agent.md

OUTPUT — always this complete structure:

```
## SAFe Classification — [topic]

### Work item type
[ Epic / Feature / Story / Spike / Enabler / Bug ]
Justification: [why this classification — size, business value, team scope]

### Epic description (if Epic)
Name: [concise Epic name — 5-8 words]
Hypothesis: [if we [do X], we believe [result Y], measurable by [metric Z]]
Business value: [WSJF input — user/business value, time criticality, risk reduction, job size]
WSJF score: [estimate 1-10 or qualitative: LOW/MEDIUM/HIGH/CRITICAL]
Leading indicator: [how we know it is working before the Epic closes]

### Feature breakdown (if Epic or Feature)
Feature 1: [name — one Sprint team sprint capability]
Feature 2: [name]
Feature 3: [name if applicable]

### Story / Acceptance criteria (if Story)
As a [user/persona], I want [action] so that [benefit].
Acceptance criteria:
- Given [context], when [action], then [expected outcome]
- Given [context], when [action], then [expected outcome]
Definition of Done: [specific, testable completion criteria]

### PI placement
Current PI: [what is in flight now]
Recommended placement: [Current PI sprint X / Next PI / Future backlog / Immediate — unplanned]
Rationale: [why this PI, why this sprint]

### Team and capacity
Owner team: [IAM pillar / security team]
Estimated size: [S/M/L/XL or story points if known]
Current capacity: [available / constrained]

### ART dependencies
Dependencies: [list teams / none]
Flagged to ART: [Y/N — if Y, coordination required at PI planning]

### Regulatory urgency
Compliance driver: [NYDFS / PCI / NIST / internal policy / none]
Regulatory deadline: [specific date / exam cycle / none]
WSJF urgency: [HIGH — compliance item / standard]
```
