# /plan
# Usage: /plan [objective or initiative]
# Writes a structured plan with phases, milestones, owners, dependencies, risks.
# Applies SAFe methodology and regulatory awareness automatically.

Write a plan for: $ARGUMENTS

OUTPUT FORMAT:

```
# Plan: [objective — clear title]
Version: 1.0 | Date: [today] | Owner: IAM Senior Lead Engineer
Status: DRAFT

## Objective
[One paragraph — what success looks like. Measurable outcome.]

## Scope
In scope: [explicit list]
Out of scope: [explicit list — prevents scope creep]

## Regulatory / policy alignment
[Which NIST/NYDFS/PCI controls this plan addresses or depends on]
[Which enterprise policies apply]

## Phases and milestones
### Phase 1 — [name] [timeframe]
| Milestone | Owner | Due | Dependency | Status |
|-----------|-------|-----|-----------|--------|
| [action]  | [team]| [date] | [prereq] | NOT STARTED |

### Phase 2 — [name] [timeframe]
[same table structure]

### Phase 3 — [name] [timeframe]
[same table structure]

## SAFe backlog items
[Epic / Feature / Story classification per /safe format]
PI placement: [current / next / future]

## Dependencies
| Dependency | Team/system | Required by | Status |
|-----------|-------------|-------------|--------|

## Risks
| Risk | Likelihood | Impact | Mitigation | Owner |
|------|-----------|--------|-----------|-------|
| [risk] | H/M/L | H/M/L | [action] | [team] |

## Success metrics
[How we measure this plan worked — quantitative where possible]

## Communication plan
| Audience | Format | Cadence | Owner |
|---------|--------|---------|-------|
| CISO/Leadership | Status summary | Monthly | IAM Lead |
| Principals/Architects | Technical update | Bi-weekly | IAM Lead |
| GRC/Risk | Evidence package | Per milestone | IAM Lead |
```
