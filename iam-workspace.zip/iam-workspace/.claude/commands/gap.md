# /gap
# Usage: /gap [brief description of finding]
# Creates a structured gap register entry in FINDING_FORMAT instantly.
# Works in any mode — use whenever you identify a gap during any session.

Create a gap register entry for: $ARGUMENTS

Load FINDING_FORMAT.md.
Using the context of the current session (tool involved, evidence seen, reg implications),
populate a complete finding record.

Auto-populate what you know:
- Finding ID: IAM-[next sequential number]-[tool-short-code from FINDING_FORMAT.md]
- Date: today
- Session type: [current mode]
- Tools involved: [from current context]
- Regulatory violations: cross-reference QUICK-REF.md Section 6 for this scenario

Ask for ONLY the fields you cannot determine from context:
- Evidence artifact filename (if not provided)
- Specific account/server/config value (if not mentioned)

Output the complete finding record ready to paste into:
1. assessment/findings/[finding-id].md (save this file)
2. assessment/gap-register.md (append this row)
3. ServiceNow Problem record (show fields separately)

After creating the file, confirm:
"Finding IAM-[X] created. Add to gap-register.md? [Y to confirm]"
