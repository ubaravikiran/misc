# /agent
# Usage: /agent [toolname]
# Spawns a focused subagent analysis from a single tool's perspective.
# Use inside a CONSULT session after the main response.
# Also usable standalone: /agent okta [topic]

Spawn a focused IAM agent analysis for: $ARGUMENTS

Parse the tool name from the argument. Valid tools:
ad, entra, azure-ad, adconnect, okta, arcon-pam, arcon-epm, cyberark, 1password,
opentext-netiq, opentext-oig, specops, radiant-logic, silverfort, groupid,
intune, keyfactor, siteminder, o365, datadog, servicenow, tableau,
google-secops, cortex-xdr, xsoar

If a second argument is provided (e.g., /agent okta mfa-enforcement-change),
scope the analysis to that specific topic.
Otherwise, use the current conversation context as the topic.

OUTPUT FORMAT:
```
## [Tool Name] — Agent Analysis
Topic: [current consultation topic]

### Architecture impact
[How this topic/change/issue specifically affects this tool in our environment]
Reference our specific config from CONTEXT.md where relevant.

### Risk assessment
[What breaks, what gets exposed, what compliance gap opens]
Severity: [🔴 Critical / 🟡 High / 🟢 Low]

### Configuration required
[What must change in this tool if the proposal/issue is addressed]
Specific: config path, API, PowerShell, admin portal location.

### Evidence to verify
Command or query to confirm the current state or verify the fix:
`[exact command/query]`
Expected output if healthy: [what good looks like]
Red flag output: [what bad looks like]

### Cross-tool dependencies
[Other tools this tool talks to that are also affected]
Sequence: [if order of operations matters]

### Verdict
[APPROVE / CONDITIONAL / REJECT / INVESTIGATE-FURTHER]
Reason: [one sentence]
Condition (if conditional): [what must be confirmed or done first]
```

Load vendor summary from knowledge-base/vendor-summaries/[tool].md if it exists.
If it doesn't exist, work from CONTEXT.md and general knowledge of that tool.
Flag at the end: "Vendor summary for [tool] not yet built — recommend building it."
