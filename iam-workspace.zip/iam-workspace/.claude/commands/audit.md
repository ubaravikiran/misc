# /audit
# Usage: /audit [scope — tool, pillar, process, or control area]
# Generates a security audit checklist for the specified scope.
# Produces evidence collection checklist with commands, NIST/NYDFS/PCI mapping.

Generate audit checklist for: $ARGUMENTS

DETECT scope and load relevant checklist:
- AD / Directory Services → NIST AC-2, AC-6, AU-2, CM-6, IA-4, IA-5
- PAM / Privileged Access → NIST AC-2(7), AC-6(1), IA-2(1), NYDFS §500.7, PCI Req 8.6
- Access Reviews / IG → NIST AC-2, AC-5, NYDFS §500.7, PCI Req 7.1
- Conditional Access / MFA → NIST IA-2(1/2), NYDFS §500.12, PCI Req 8.3/8.4
- Service Accounts / NHI → NIST AC-2, IA-5, CM-8, NYDFS §500.7, PCI Req 8.6
- Logging / Monitoring → NIST AU-2, AU-6, AU-11, AU-12, NYDFS §500.14

OUTPUT FORMAT per checklist item:
```
## Audit Checklist — [scope]
Reference: NIST 800-53 Rev5 + NYDFS Part 500 + PCI DSS v4.0 + Enterprise Policy

| # | Control | NIST | NYDFS | PCI | Evidence command / action | Pass criteria | Status |
|---|---------|------|-------|-----|--------------------------|---------------|--------|
| 1 | [control name] | [ctrl ID] | [§xxx] | [Req] | `[exact command]` | [what pass looks like] | [ ] |
```

For each checklist item include:
1. The exact PowerShell/CLI command to collect evidence
2. What the output should look like if compliant
3. What a non-compliant output looks like
4. The NIST + NYDFS + PCI control simultaneously

After checklist:
"Run /gap [finding description] for any item that does not pass to create a formal gap register entry."
"Use mcp__confluence__ to post this checklist as an audit preparation page."
