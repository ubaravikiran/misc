# /investigate
# Usage: /investigate [symptom, alert, or anomaly description]
# Triggers INVESTIGATE mode — systematic multi-system correlation.
# Covers: SIEM, DC logs, Entra/Defender, Silverfort, Okta, Arcon PAM,
#         Datadog, Palo Alto, PowerShell/AD, vCenter, Intune, Cortex XDR, XSOAR

Enter INVESTIGATE mode for: $ARGUMENTS

INVESTIGATION PROTOCOL:

STEP 1 — SCOPE DETERMINATION (silent, from symptom)
- Determine: which identity type(s) involved
- Determine: which OpCo(s) in scope  
- Determine: which systems are the most likely source vs correlating systems
- Determine: is this an active incident or post-incident analysis
- State scope in one line at the top

STEP 2 — INVESTIGATION FRAMEWORK
Build the check sequence in priority order based on symptom type:

For AUTH FAILURES / LOCKOUTS:
Priority: DC Security Log → Silverfort → Entra Sign-in logs → Okta system log →
          Palo Alto (if VPN involved) → Arcon PAM (if svc acct) → Datadog

For LATERAL MOVEMENT / SUSPICIOUS ACCESS:
Priority: Silverfort → DC Security Log (4648, 4624 type 3) → Cortex XDR →
          Google SecOps SIEM → Entra/Defender → Palo Alto → Arcon PAM session log

For SERVICE ACCOUNT ANOMALY:
Priority: Arcon PAM session log → DC Security Log → Google SecOps →
          Datadog (process/service metrics) → ServiceNow (recent changes)

For PROVISIONING / SYNC ISSUES:
Priority: NetIQ/MyAccess log → ADConnect sync log → Entra provisioning log →
          Okta system log → AD replication → GroupID

For ENDPOINT / EPM ISSUES:
Priority: Arcon EPM log → Intune compliance → DC Security Log →
          Cortex XDR → Datadog agent → Palo Alto (outbound)

For CERTIFICATE / PKI ISSUES:
Priority: Keyfactor → DC Security Log (CAPI2) → Entra token log →
          IIS/App logs → Silverfort (auth failures post-cert)

STEP 3 — FOR EACH SYSTEM IN SEQUENCE, PROVIDE:

```
### [System Name]
Platform: [where to access this — portal URL pattern, PowerShell module, CLI]
Query/command:
  [exact query — Google SecOps KQL, PowerShell, sqlite3, etc.]
Look for:
  - [specific indicator 1] → means: [implication]
  - [specific indicator 2] → means: [implication]
Pivot: if you find [X] here → go to [system Y] and check [specific thing]
```

STEP 4 — CORRELATION MATRIX
Build a table showing which fields correlate across systems:
| System | Key field | Correlates with | Purpose |
|--------|-----------|----------------|---------|

STEP 5 — TIMELINE RECONSTRUCTION TEMPLATE
Provide an empty table for the investigator to fill as evidence comes in:
| Time (UTC) | System | Event | Account | Source IP | Significance |

STEP 6 — PIVOT DECISION TREE
If [finding] → [next action] format for the most likely findings.
When to escalate to SecOps / CTI / Server team / Legal.

QUERY FORMATS TO INCLUDE:

Google SecOps (Chronicle) — UDM format:
```
metadata.event_type = "USER_LOGIN" AND
principal.user.userid = "[account]" AND
timestamp >= [time range]
```

PowerShell AD:
```powershell
Get-ADUser -Identity [user] -Properties *
Get-WinEvent -ComputerName [DC] -FilterHashtable @{LogName='Security'; Id=4625; StartTime=[time]}
```

Datadog — metric query pattern:
```
avg:system.cpu.user{host:[hostname]} by {host}
```

Palo Alto — log query pattern:
```
(addr.src in [IP]) and (port.dst eq [port])
```

TONE: Systematic and exhaustive. This is forensic work. Every system gets checked.
Nothing is assumed until evidence confirms. Always build toward a timeline.
