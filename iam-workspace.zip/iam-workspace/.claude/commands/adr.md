# /adr
# Usage: /adr [decision to document]
# Creates an Architecture Decision Record. Confluence-ready.
# Captures: context, options considered, decision made, consequences.

Create an ADR for: $ARGUMENTS

ADR FORMAT (based on Michael Nygard template, adapted for IAM):

```
# ADR-[NNN]: [Short title of decision]
**Status:** [Proposed / Accepted / Deprecated / Superseded by ADR-NNN]
**Date:** [DATE]
**Deciders:** IAM Senior Lead Engineer, ICS Architect, [others]
**Technical story:** [ServiceNow ticket or initiative reference]

---

## Context and problem statement
[Describe the context and the problem that needs to be solved.
What is the issue that we are trying to solve? Be specific to our environment:
3 OpCos, multi-forest AD, Entra hybrid, Okta migration underway, IG unstable.]

## Decision drivers
- [Driver 1 — e.g., regulatory requirement: NYDFS §500.7]
- [Driver 2 — e.g., operational constraint: IG not enterprise-functional]
- [Driver 3 — e.g., security requirement: MFA for all privileged access]

## Considered options
- Option 1: [name]
- Option 2: [name]
- Option 3: [name]

## Decision outcome
Chosen option: [Option X], because [justification — evidence-based, not preference-based].

### Consequences
**Good:**
- [Positive outcome 1]
- [Positive outcome 2]

**Bad:**
- [Trade-off or accepted risk 1]
- [Technical debt created if any]

**Neutral:**
- [Side effect that is neither good nor bad]

## Pros and cons of the options

### Option 1 — [name]
[Brief description]
- Pro: [advantage]
- Pro: [advantage]
- Con: [disadvantage]
- Con: [disadvantage]

### Option 2 — [name]
[Same structure]

### Option 3 — [name]
[Same structure]

## Links
- [Related ADR, runbook, or Confluence page]
- [Regulatory reference]
```
