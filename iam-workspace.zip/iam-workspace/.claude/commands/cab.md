# /cab
# Usage: /cab [paste change order content]
# Triggers CAB REVIEW mode.
# Automatically queries SQLite DB for historical incidents related to this change.

Enter CAB REVIEW mode for the following change order: $ARGUMENTS

STEP 1 — PARSE THE CHANGE ORDER
Extract and restate in your own words:
- What is actually changing (not what the author wrote — what it REALLY does to IAM)
- Which tools/systems are affected
- Which identity types are affected (human / NHI / both)
- Which OpCo(s) are in scope
- Stated rollback plan

STEP 2 — QUERY INCIDENT HISTORY (SQLite DB)
Run the following Python queries against data/iam-servicenow.db:

```python
import sqlite3, pandas as pd
conn = sqlite3.connect('data/iam-servicenow.db')

# 1. Find incidents related to same tool/component in last 12 months
similar_incidents = pd.read_sql_query("""
    SELECT number, short_description, priority, state, 
           opened_at, resolved_at, close_notes, cause_code
    FROM incidents 
    WHERE (short_description LIKE '%[TOOL]%' OR description LIKE '%[TOOL]%')
    AND opened_at >= date('now', '-12 months')
    ORDER BY priority ASC, opened_at DESC
    LIMIT 20
""", conn)

# 2. Find related problem tickets
related_problems = pd.read_sql_query("""
    SELECT number, short_description, root_cause, workaround, state
    FROM problems
    WHERE short_description LIKE '%[TOOL]%'
    AND opened_at >= date('now', '-12 months')
""", conn)

# 3. Find similar past change orders that caused incidents
risky_changes = pd.read_sql_query("""
    SELECT c.number, c.short_description, c.state, c.close_code,
           COUNT(i.number) as incident_count
    FROM change_orders c
    LEFT JOIN incidents i ON i.short_description LIKE '%' || c.number || '%'
    WHERE c.short_description LIKE '%[TOOL]%'
    AND c.opened_at >= date('now', '-12 months')
    GROUP BY c.number
    ORDER BY incident_count DESC
    LIMIT 10
""", conn)

conn.close()
```

Replace [TOOL] with the actual tool(s) identified in Step 1.
If pandas is unavailable, fall back to sqlite3 CLI queries.
Show query results as a formatted table — not raw output.

STEP 3 — PRODUCE CAB REVIEW OUTPUT
Follow the CAB REVIEW output format from CLAUDE.md exactly:
- IAM Pre-CAB Verdict (APPROVE / APPROVE WITH CONDITIONS / REJECT)
- What this change actually does (translated)
- What they got wrong or missed (table with incident evidence)
- Historical precedent from DB query results
- Questions they must answer before CAB
- Rollback assessment (stated vs reality)
- IAM conditions for approval
- Education note (teach the right approach)

TONE FOR CAB:
This person chairs IAM pre-CAB. They are dealing with teams who submit poorly
understood changes. Be direct and technical. The "Education note" should explain
the RIGHT way to approach this change — respectful but authoritative.
Reference specific incidents by number when available from the DB.
"INC0012345 was caused by this exact pattern in March" is more powerful than theory.
