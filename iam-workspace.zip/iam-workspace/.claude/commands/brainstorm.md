# /brainstorm
# Usage: /brainstorm [topic or problem statement]
# Structured brainstorming with IAM expertise context.
# Produces: problem reframing, ideas ranked by feasibility/impact, questions to sharpen thinking.

Brainstorm for: $ARGUMENTS

STRUCTURE:

## Problem reframing
[Restate the problem 3 ways — different angles often reveal unstated constraints]
1. [Original framing]
2. [Reframed as a process problem]
3. [Reframed as a technology gap]

## Context check (from CONTEXT.md)
[Which tools, OpCos, identity types, or regulatory requirements are directly relevant]
[Any known open gaps from gap register that this brainstorm touches]

## Ideas — high feasibility / high impact
[3-5 ideas executable with current tools and team capacity]
For each: one-line description | tools required | rough effort | regulatory benefit

## Ideas — lower feasibility / higher impact
[2-3 ideas requiring new tooling or significant effort]
For each: one-line description | what would need to change | strategic value

## Unconventional angles
[1-2 ideas that challenge the assumption in the problem statement]

## GTI / threat perspective
[What does the threat landscape say about this problem? Are we solving for the right threat?]

## Questions to sharpen the problem
[5 questions that would change the answer if the answer changed]
1. [question]
2. [question]
3. [question]
4. [question]
5. [question]

## Recommended next step
[One concrete action to take based on this brainstorm — specific, owned, time-bound]
