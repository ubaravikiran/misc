# /troubleshoot
# Usage: /troubleshoot [symptom description]
# Triggers TROUBLESHOOT mode. Paste symptom after the command.
# Claude loads CONTEXT.md + QUICK-REF.md + relevant vendor summary automatically.

Enter TROUBLESHOOT mode for the following symptom: $ARGUMENTS

Follow the TROUBLESHOOT output format from CLAUDE.md exactly:
- Likely cause (one sentence)
- Ordered commands with single-line "Why" for each
- Fix with counter-argument
- Reg/policy impact

Load the relevant vendor summary from knowledge-base/vendor-summaries/ based on the tools involved.
If the tool summary doesn't exist yet, work from CONTEXT.md knowledge of that tool.
Do not ask clarifying questions — make the best determination from the symptom and proceed.
If multiple tools are implicated, list them in priority order of likely cause.
