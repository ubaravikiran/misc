# /debate
# Usage: /debate [paste ticket, proposal, change order, or problem description]
# Triggers the full multi-agent debate. Auto-selects relevant agents. All vote. You decide.
#
# Also triggers automatically when CLAUDE.md detects debate-pattern keywords:
# "what do the agents think", "run this through the team", "debate this",
# "get all opinions on", "pre-CAB debate", "team vote on"

---

## STEP 1 — PARSE AND SCOPE (silent, no output yet)

Read: $ARGUMENTS
Identify:
- Topic type: [ Change Order | Incident/Problem | Architecture Proposal | Process Gap | Access Request | Other ]
- IAM pillars touched: [ FID | PPM | PaLM | IAC | CyberSquad | cross-pillar ]
- Other orgs touched: [ CTD | ISE | RISE | EIRM | DR | none ]
- Regulatory dimension: [ NYDFS | PCI | NIST | MAR | none ]
- SQLite DB relevance: [ high — query INSIGHTS.md | low — skip ]

---

## STEP 2 — AGENT SELECTION (auto, based on scope)

Always load these core agents for every debate:
- .claude/agents/ics/architect.md      (technical authority — always present)
- .claude/agents/ics/principal.md      (cross-pillar + DB evidence — always present)
- .claude/agents/special/safe-agent.md (SAFe framing — always present)
- .claude/agents/special/threat-model-agent.md (STRIDE — always present)

Load based on pillar touched:
- FID pillar touched → .claude/agents/ics/fid-engineer.md
- PPM pillar touched → .claude/agents/ics/ppm-engineer.md
- PaLM pillar touched → .claude/agents/ics/palm-engineer.md
- IAC/IG pillar touched → .claude/agents/ics/iac-engineer.md
- Operational/L1 impact → .claude/agents/ics/cybersquad.md
- Executive/political/regulatory → .claude/agents/ics/director.md
- Roadmap/business case → .claude/agents/ics/manager.md

Load based on other orgs:
- Threat/detection dimension → .claude/agents/ctd/secops.md
- Intelligence/TTP dimension → .claude/agents/ctd/cti.md
- Vulnerability dimension → .claude/agents/ctd/evm.md
- SDLC/code dimension → .claude/agents/ctd/appsec.md
- Insider risk dimension → .claude/agents/ctd/iri.md
- Automation/cert/DLP → .claude/agents/ise/adp.md
- Network/firewall/endpoint → .claude/agents/ise/defeng.md
- Cloud security → .claude/agents/ise/plateng.md
- Control testing/evidence → .claude/agents/ise/scta.md
- Risk consulting/ARA/permit → .claude/agents/ise/soleng.md
- Enterprise risk → .claude/agents/rise/rise.md
- Compliance/policy → .claude/agents/rise/eirm-drc.md
- DR/resiliency → .claude/agents/rise/enterprise-dr.md

Token rule: Never load more than 8 agents in one debate.
If more than 8 are relevant, load the 6 most directly impacted + Architect + Principal.
State which agents were omitted and why.

---

## STEP 3 — PRINCIPAL AGENT DB CHECK

Before any agent votes, Principal agent runs:
"Read data/INSIGHTS.md. Find any pattern match for: [topic keywords].
Report: matching incident categories, change-caused-incident patterns,
relevant ticket numbers for citation. If no match, state: 'No INSIGHTS pattern match.'"

Output format:
```
## Principal — DB Pattern Check
Pattern match: [YES — Section 1, Category: X, Count: N, Tickets: INC-XXXX, INC-XXXX]
               [NO MATCH — proceeding without historical evidence]
Open problems related: [PRB-XXXX] or [none]
```

---

## STEP 4 — DEBATE (each agent states position)

Each agent produces their vote block using their file's VOTE FORMAT.
Order: most-likely-to-reject first (surfaces strongest objections early).
Typical order: Architect → Threat Model → Principal → FID/PPM/PaLM/IAC → 
               CTD agents → ISE agents → RISE agents → SAFe → Manager → Director

Rules:
- Direct and blunt. No hedging. Evidence-anchored.
- Max 4 sentences of reasoning per agent.
- Must cite specific control ID, ticket number, policy section, or INSIGHTS pattern.
- Must explicitly flag agreement with another agent if it exists.
- No AI-sounding language. These agents argue like the domain experts they represent.

---

## STEP 5 — VOTE TABLE

```
## VOTE SUMMARY

| Agent | Org | Vote | Key condition / evidence |
|-------|-----|------|--------------------------|
| ICS Architect | ICS | [verdict] | [one-line] |
| ICS Principal | ICS | [verdict] | [ticket or pattern] |
| Threat Model | Special | [verdict] | [STRIDE vector] |
| SAFe Agent | Special | [verdict] | [PI/epic/capacity] |
| [other agents...] | | | |

VOTE COUNT: APPROVE: N | CONDITIONAL: N | REJECT: N

MAJORITY RECOMMENDATION: [APPROVE WITH CONDITIONS / REJECT / APPROVE]
Reason: [one sentence — the decisive factor]

CONDITIONS (if conditional majority):
1. [specific condition before proceeding]
2. [specific condition]

DISSENT NOTE (if you override):
Type: OVERRIDE [APPROVE/REJECT]
Claude will ask for your reasoning before recording.
```

---

## STEP 6 — OVERRIDE HANDLING

If user types: "I'm overriding this" or "Override to [verdict]"

Respond:
"Override recorded as [verdict].

Before I update the agent context, what is your reasoning?
Specifically: what does this decision account for that the [dissenting agents] missed?"

After receiving reasoning:
1. Record to the relevant agent's override_history field
2. If reasoning reveals a knowledge gap in the agent: update that agent's vote_logic_updates
3. Confirm: "Override logged. [Agent] context updated. The next debate on this topic
   will account for: [what you provided]."

---

## STEP 7 — BACKLOG ENTRY (automatic)

After every debate, output:
```
## Backlog / Gap Register
Action required: [YES / NO]

If YES:
- Gap finding: /gap [brief description] to create formal finding
- ServiceNow: [suggest Incident / Problem / Change / SR based on type]
- SAFe backlog: [Epic / Feature / Story | PI: current / next / future]
- Owner: [recommended team or pillar]
```

---

## TOKEN BUDGET FOR DEBATE SESSIONS
- 4 agents: ~4,500 tokens context | 6 agents: ~6,500 tokens | 8 agents: ~8,500 tokens
- INSIGHTS.md: ~1,500 tokens (always in CAB debates)
- Stay within 8 agents to keep session under 10k tokens total context
