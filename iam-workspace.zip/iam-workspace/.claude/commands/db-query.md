# /db-query
# Usage: /db-query [plain English question about incident/change/problem history]
# Translates your question into SQLite, runs it, returns formatted results.

Translate this question into a SQLite query and run it against data/iam-servicenow.db: $ARGUMENTS

PROTOCOL:

STEP 1 — DB SCHEMA CHECK (first time only per session)
If schema not yet known this session, run:
```python
import sqlite3
conn = sqlite3.connect('data/iam-servicenow.db')
cursor = conn.cursor()
cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
tables = cursor.fetchall()
for table in tables:
    cursor.execute(f"PRAGMA table_info({table[0]})")
    print(f"\n{table[0]}:", cursor.fetchall())
conn.close()
```
Cache the schema for the rest of the session — don't re-query it.

STEP 2 — TRANSLATE TO SQL
Convert the plain English question to SQL.
Show the query before running it (one line: "Query: [SQL]").

STEP 3 — EXECUTE
```python
import sqlite3, pandas as pd
conn = sqlite3.connect('data/iam-servicenow.db')
df = pd.read_sql_query("[YOUR SQL]", conn)
conn.close()
print(df.to_string())
```
Fall back to sqlite3 CLI if pandas unavailable:
```bash
sqlite3 data/iam-servicenow.db "[YOUR SQL]"
```

STEP 4 — INTERPRET RESULTS
Don't just return raw data. After the table:
- Pattern: [what the data shows]
- IAM implication: [what this means operationally]
- Recommendation: [action if any]

COMMON QUERY PATTERNS (reference these):

Repeat incidents by tool last 12 months:
SELECT short_description, COUNT(*) as count, MAX(priority) as highest_priority
FROM incidents WHERE opened_at >= date('now','-12 months')
GROUP BY category ORDER BY count DESC

P1/P2 incidents caused by IAM:
SELECT number, short_description, opened_at, resolved_at, close_notes
FROM incidents WHERE priority IN ('1','2','P1','P2')
AND opened_at >= date('now','-12 months')
ORDER BY opened_at DESC

Changes that triggered incidents (within 48hrs):
SELECT c.number, c.short_description, c.end_date, i.number as incident, i.opened_at
FROM change_orders c JOIN incidents i
ON i.opened_at BETWEEN c.end_date AND datetime(c.end_date, '+48 hours')
ORDER BY c.end_date DESC

Open problems with no root cause:
SELECT number, short_description, opened_at, state
FROM problems WHERE root_cause IS NULL OR root_cause = ''
AND state NOT IN ('Closed','Resolved')

SLA breaches last 90 days:
SELECT number, short_description, priority, opened_at, resolved_at,
julianday(resolved_at) - julianday(opened_at) as days_to_resolve
FROM incidents WHERE days_to_resolve > 4 AND priority IN ('1','2','P1','P2')
AND opened_at >= date('now','-90 days')
ORDER BY days_to_resolve DESC
