# /analyze
# Usage: /analyze [data, dataset, question, or export file]
# Data analysis with IAM security context. Handles CSV exports, counts, trend analysis.
# Applies IAM risk lens to data patterns.

Analyze: $ARGUMENTS

DETECT analysis type:
- AD/directory export → stale accounts, orphaned objects, privilege creep
- PAM vault export → unvaulted accounts, rotation compliance, NHI governance gaps
- Okta export → dormant users, app assignment anomalies, MFA enrollment gaps
- Access review data → entitlement anomalies, SoD conflicts, over-provisioned roles
- Incident/ticket data → pattern analysis, frequency, team performance
- Metrics/numbers → statistical summary, trend, anomaly detection
- Generic dataset → profiling, distribution, outlier detection

OUTPUT FORMAT:
```
## Analysis — [subject]
Date: [today] | Dataset: [description]

## Summary (executive-level)
[3-5 sentence summary of key findings — what does this data mean for IAM risk?]

## Key findings
| # | Finding | Count / Value | Risk | Control reference |
|---|---------|--------------|------|-----------------|
| 1 | [finding] | [N] | [H/M/L] | [NIST ctrl / NYDFS §] |

## Anomalies / outliers
[Specific data points that deviate from expected patterns]

## Trend (if time-series data)
[Direction, rate of change, comparison to prior period]

## IAM risk interpretation
[What these numbers mean in the context of our environment — not just statistics]
[Which gaps from the gap register does this data confirm or quantify?]

## Recommended actions
1. [Specific action — owner, timeline, ticket type]
2. [Specific action]

## GTI context (if security-relevant data)
[Query GTI if data contains IOCs or if patterns suggest compromise]

## Visualization
[If data warrants it: offer to generate a Mermaid diagram or table visualization]
```
