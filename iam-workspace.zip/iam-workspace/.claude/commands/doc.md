# /doc
# Usage: /doc [topic — what document to create and for whom]
# Creates structured documentation. Confluence-ready markdown.
# Covers: runbooks, process docs, architecture docs, policy position papers, how-to guides.

Create documentation for: $ARGUMENTS

DETECT document type and apply appropriate template:

RUNBOOK → operational procedure, step-by-step, L1/L2 executable
PROCESS DOC → JML flows, ITIL processes, operational workflows
ARCHITECTURE DOC → design decisions, component diagrams, integration specs
POLICY POSITION → IAM position on a topic (for consultation or CAB)
HOW-TO GUIDE → end-user or team member instructions
RCA/INCIDENT DOC → post-incident documentation (use ESCALATION-RCA.md instead)

STANDARD STRUCTURE (apply to all types):
```
# [Document Title]
**Type:** [Runbook / Process / Architecture / Policy Position / How-To]
**Owner:** IAM Senior Lead Engineer
**Last updated:** [DATE]
**Audience:** [specific role or team]
**Status:** [Draft / Review / Approved / Deprecated]
**Confluence path:** [suggested space/page path]

---

## Purpose
[One paragraph — why this document exists and when to use it]

## Scope
[What this covers and what it does not cover]

## Prerequisites
[What must be true before following this document]

## [Main content sections based on document type]

## Escalation path
[When to escalate beyond this document, to whom]

## Related documents
[Links or references to related runbooks/processes]

## Revision history
| Version | Date | Author | Change |
|---------|------|--------|--------|
| 1.0 | [DATE] | IAM Senior Lead | Initial |
```

After generating the document, offer:
- "Post this to Confluence? Use mcp__confluence__ to create the page."
- "/gap if this document reveals a process gap that should be in the gap register"
