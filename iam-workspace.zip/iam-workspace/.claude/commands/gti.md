# /gti
# Usage: /gti [IOC, CVE, threat actor name, or technology topic]
# Direct GTI query. Use anytime for threat intelligence lookups.
# Auto-triggered by INVESTIGATE, CONSULT, CAB, DEBATE modes per GTI_ALWAYS_ON rules.

Enter GTI query for: $ARGUMENTS

STEP 1 — DETECT QUERY TYPE
Classify the input:
- IP address → mcp__google-threat-intelligence__ IOC reputation lookup
- File hash (MD5/SHA1/SHA256) → file reputation + malware family
- Domain / URL → domain reputation + phishing/malware association
- CVE-XXXX-XXXX → CVE details + CVSS + exploitation status + affected products
- Threat actor name / group → actor profile + TTPs + targeted sectors + IAM relevance
- Technology name → known CVEs + threat actor interest + recent advisories
- MITRE technique ID → technique description + detection methods + IAM applicability

STEP 2 — QUERY GTI VIA MCP
Use the appropriate mcp__google-threat-intelligence__* tool based on query type.
If GTI returns no data, state explicitly: "No GTI data found for [query]. Proceeding with MITRE baseline."

STEP 3 — OUTPUT FORMAT
```
## GTI Results — [query]
Query type: [IOC / CVE / Actor / Technology]
GTI verdict: [MALICIOUS / SUSPICIOUS / CLEAN / NOT FOUND]
Details: [specific finding — severity, confidence, attribution]
Active exploitation: [YES — confirmed in wild / NO / UNKNOWN]
Relevant to our stack: [YES — affects [tool] version [X] / NO — explain why not]
Threat actor: [known actor if attributed]
MITRE techniques: [T-XXXX if mapped in GTI]
IAM-specific risk: [how this applies to our AD/Entra/Okta/PAM environment specifically]
Recommended action: [specific next step — patch / block / monitor / investigate]
GTI confidence: [HIGH / MEDIUM / LOW]
```

STEP 4 — IAM ENVIRONMENT MAPPING
Always connect GTI findings to specific tools in our stack:
- Network IOC → check Palo Alto firewall logs, Silverfort auth events
- File hash → Cortex XDR, Defender scan, Datadog endpoint agent
- CVE → identify affected tool version in our environment, check Arcon/AD/Okta patch status
- Threat actor → map their IAM TTPs to our specific vulnerability surface
- Technology → check which specific instances we run and their patch level
