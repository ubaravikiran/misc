# /email
# Usage: /email [situation description — who, what, context, desired outcome]
# Drafts professional emails. Multiple tone variants for different situations.
# Output does NOT sound like AI. Direct, professional, evidence-grounded.

Draft an email for: $ARGUMENTS

PARSE the situation:
- Audience: [internal peer / manager / director / CISO / vendor / external team]
- Type: [escalation / recommendation / status update / pushback / request / RCA summary]
- Tone needed: [diplomatic / direct / urgent / collaborative / formal]
- Evidence available: [Y/N — incorporate if yes]

OUTPUT — 2-3 variants depending on situation complexity:

### Variant 1 — [tone label: e.g., "Direct and factual"]
Subject: [specific, not vague — reader knows exactly what action is needed]
---
[Email body — no AI preamble, no "I hope this email finds you well"]
[Opening: state the purpose in sentence 1]
[Context: 1-2 sentences of relevant background]
[Core message: evidence-backed, specific]
[Ask or action: explicit — what do you need from the recipient, by when]
[Optional: next steps if no response by [date]]
---

### Variant 2 — [tone label: e.g., "Diplomatic but firm"]
Subject: [different framing]
---
[Alternative approach — same facts, different framing]
---

RULES:
- Never say "per my previous email", "as mentioned", "going forward", "I wanted to reach out"
- State the evidence — numbers, ticket numbers, control IDs where relevant
- Every ask is explicit: "I need [X] by [date]" not "please consider"
- If regulatory stakes exist, name the regulation: "This is a NYDFS §500.7 compliance requirement"
- Maximum 200 words per variant unless situation requires more
- Write like a Senior Lead who has been in the room, not like a draft assistant
