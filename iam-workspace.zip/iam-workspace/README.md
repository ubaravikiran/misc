# IAM Workspace — Master README
# Your Claude Code knowledge base, assessment engine, and daily ops system.
# Read this once. After that, edit SESSION.md and paste the session opener.

---

## The 3-step workflow (every session)

1. **Edit SESSION.md** — 4 lines, 10 seconds
2. **Paste the session opener** into Claude Code:
   `Read SESSION.md. Load only the files specified for this MODE. My task: [your task]`
3. **Work** — Claude is fully oriented to your environment, regulations, and output standard

---

## Full Directory Structure

```
iam-workspace/
│
├── SESSION.md                          ← EDIT BEFORE EVERY SESSION
├── CONTEXT.md                          ← Always loaded (org, tools, OpCos, identity types)
├── QUICK-REF.md                        ← Always loaded (NIST + NYDFS + PCI + policy digest)
├── FINDING_FORMAT.md                   ← Loaded in assessment + RCA sessions
│
├── daily-ops/
│   ├── itil/
│   │   ├── ESCALATION-RCA.md          ← Master template for P1/P2/P3 escalations
│   │   ├── CHANGE-MGMT.md             ← CAB prep, RFC template, IAM change standards [TODO]
│   │   └── PROBLEM-MGMT.md            ← Problem record, known error, trend analysis [TODO]
│   │
│   ├── consultation-templates/
│   │   └── CONSULTATION-TEMPLATES.md  ← Per-team prompts and language calibration (all teams)
│   │
│   ├── runbooks/                       ← Troubleshooting by tool (build as you go)
│   │   ├── ad-troubleshooting.md      [TODO — build from first AD escalation]
│   │   ├── okta-troubleshooting.md    [TODO]
│   │   ├── arcon-pam.md               [TODO]
│   │   ├── arcon-epm.md               [TODO]
│   │   ├── netiq-myaccess.md          [TODO]
│   │   ├── oig.md                     [TODO]
│   │   ├── entra-conditional-access.md [TODO]
│   │   └── silverfort.md              [TODO]
│   │
│   ├── meeting-notes/                  ← Structured discussion records (one file per meeting)
│   │   └── MEETING-TEMPLATE.md        [TODO]
│   │
│   └── servicenow/                     ← Ticket patterns and drafts
│       └── SR-PATTERNS.md             [TODO — common SR types and IAM response templates]
│
├── assessment/
│   ├── pillars/
│   │   ├── 01-directory-services.md   ← Assessment checklist + findings for DS pillar
│   │   ├── 02-access-management.md    ← Access Management pillar
│   │   ├── 03-pam.md                  ← PAM pillar
│   │   ├── 04-identity-admin.md       ← Identity Admin pillar
│   │   └── 05-identity-governance.md  ← Identity Governance pillar
│   │
│   ├── evidence/                       ← Command outputs, exports, screenshots
│   │   ├── ad/
│   │   ├── entra/
│   │   ├── okta/
│   │   ├── arcon-pam/
│   │   ├── arcon-epm/
│   │   ├── netiq/
│   │   ├── oig/
│   │   ├── specops/
│   │   ├── siteminder/
│   │   ├── radiant-logic/
│   │   ├── silverfort/
│   │   └── groupid/
│   │
│   ├── findings/                       ← One .md per finding (auto-named by Claude)
│   │   └── IAM-001-[tool]-[summary].md
│   │
│   ├── gap-register.md                ← Master risk register (rebuilt from findings/)
│   │
│   └── outputs/                        ← Confluence-ready pages
│       ├── exec-summary.md
│       ├── recommendations.md
│       └── confluence-pages/
│
├── knowledge-base/
│   ├── regs-raw/                       ← NEVER auto-loaded. Surgical access only.
│   │   ├── nist-800-53-rev5.pdf
│   │   ├── nist-800-63-3.pdf
│   │   ├── nydfs-part500-nov2023.pdf
│   │   └── pci-dss-v4.pdf
│   │
│   ├── policies-raw/                   ← NEVER auto-loaded. Surgical access only.
│   │   ├── iam-policy.pdf
│   │   ├── sdlc-policy.pdf
│   │   ├── logging-monitoring-policy.pdf
│   │   ├── asset-management-policy.pdf
│   │   └── data-governance-policy.pdf
│   │
│   └── vendor-summaries/               ← Load only the relevant one per session (~500 tokens each)
│       ├── VENDOR-SUMMARIES-INDEX.md
│       ├── microsoft-ad-entra.md       ← BUILT
│       ├── okta.md                     [TODO]
│       ├── arcon-pam-epm.md            [TODO]
│       ├── opentext-netiq-oig.md       [TODO]
│       ├── siteminder.md               [TODO]
│       ├── specops.md                  [TODO]
│       ├── radiant-logic.md            [TODO]
│       ├── silverfort.md               [TODO]
│       ├── groupid.md                  [TODO]
│       └── keyfactor.md               [TODO]
│
└── vendor-docs-raw/                    ← NEVER auto-loaded. Surgical access only.
    ├── microsoft/
    ├── okta/
    ├── arcon/
    ├── opentext/
    ├── broadcom-siteminder/
    ├── specops/
    ├── radiant-logic/
    ├── silverfort/
    └── keyfactor/
```

---

## Token Budget per Session Type

| Session type | Files loaded | Approx tokens | Notes |
|-------------|-------------|---------------|-------|
| Daily ops — escalation triage | CONTEXT + QUICK-REF + 1 runbook | ~5k | Flat cost always |
| Daily ops — consultation prep | CONTEXT + QUICK-REF + 1 team template | ~5k | |
| Daily ops — with vendor ref | + 1 vendor summary | ~5.5k | One vendor only |
| Assessment — pillar work | CONTEXT + QUICK-REF + FINDING_FORMAT + 1 pillar | ~8k | |
| Assessment — with evidence | + CSV/export paste | ~10-15k | Evidence drives cost |
| RCA — full package output | CONTEXT + QUICK-REF + FINDING_FORMAT + ESCALATION-RCA | ~10k | |
| Knowledge build — policy digest | 1 raw policy PDF | ~20-40k | One-time only |
| Knowledge build — reg digest | 1 raw reg PDF | ~40-180k | One-time only |
| Vendor raw doc — surgical | 1 section of 1 doc | ~5-15k | Surgical only |

---

## Build Priority — What to Build Next

### This week (highest ROI)
1. Run knowledge-build session for each enterprise policy — builds QUICK-REF.md Section 5
2. Build okta.md vendor summary (second most common escalation source)
3. Build arcon-pam-epm.md vendor summary (PAM is highest risk domain)
4. Build CHANGE-MGMT.md (CAB prep is a recurring need)

### This month
5. Build all remaining vendor summaries (one per session, low cost)
6. Run assessment pillar sessions — Directory Services first (most evidence available)
7. Build runbooks for top 3 escalation scenarios from memory

### Ongoing (as escalations occur)
- After every P1/P2: update relevant runbook with new failure mode
- After every new finding: add to gap-register.md
- After every team consultation: note what worked in the team template

---

## The Runbook Build Pattern
After resolving any escalation, run this prompt:
"Read CONTEXT.md. Here is a resolved escalation: [paste ESCALATION-RCA.md].
Extract the troubleshooting steps into a runbook entry for daily-ops/runbooks/[tool].md.
Format: symptom, likely causes, diagnostic steps (commands), resolution steps, prevention."

Over 3 months, your runbooks become the most valuable files in the repo —
built from real escalations in your specific environment, not generic vendor docs.
