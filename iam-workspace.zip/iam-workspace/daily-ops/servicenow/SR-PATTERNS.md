# SR-PATTERNS.md — Common Service Request Patterns and IAM Responses
# Quick reference for frequent request types — responses are templated, not written from scratch each time

## SR Type: New User Access Request
**Received from:** Manager, HR, Business owner
**IAM response template:**
```
Thank you for the access request for [user].
Before provisioning, the following is required:
1. User account type confirmed: [primary / secondary / contractor — which HR source?]
2. Business justification: [what systems and why]
3. Manager approval: [attached / required]
4. RBAC/modelID basis: [which role model applies?]
5. SoD check: [does this create a conflicting entitlement?]

Processing time: [X business days per ICS IAM SLA]
Route: [ICS IAM ServiceNow queue]
```

## SR Type: Elevated Access Request
**Received from:** Developer, admin, project team
**IAM response template:**
```
Elevated access requires:
1. Business justification and time-bound duration
2. Manager approval
3. PAM enrollment: service account must be vaulted in Arcon PAM before use
4. EPM justification if local admin required
5. Approval from IAM Lead for standing admin rights

Note: Preference is JIT elevation via Arcon EPM over standing admin rights.
JIT deployment in progress — current process: time-limited group membership with documented justification.
```

## SR Type: Service Account Request
**Received from:** Application team, DevOps
**IAM response template:**
```
Service account provisioning requirements:
1. Application name and APM# (CMDB reference)
2. Intended use: interactive vs gMSA (gMSA preferred where possible)
3. Required permissions: specify minimum — least privilege (AC-6)
4. PAM vault enrollment: mandatory — no standalone credentials
5. Rotation policy: confirm programmatic retrieval via PAM API or scheduled rotation
6. Code review confirmation: no hardcoded credentials in application code (IA-5(7))
7. CMDB update: APM# must reference this service account (pending CMDB enhancement)

Processing: PAM enrollment + AD account creation. Timeline: [X business days]
```

## SR Type: Access Removal (Leaver or Role Change)
**Received from:** HR, manager, security team
**IAM response template:**
```
Access removal confirmed. Processing:
- Primary account: NetIQ/MyAccess handles disable on termination event
- Secondary accounts: manual process — IAC Ops team
- Ghost accounts: manual process — IAC Ops team
- PAM vault: service accounts owned by this user — transferring ownership to [manager]
- Active sessions: Arcon PAM session termination if active

Immediate termination (insider risk): same-day processing — contact IAM Lead directly.
Standard termination: processed within [X hours] of Workday/Simplify event.
```

## SR Type: Password Reset (beyond Specops scope)
**Received from:** CyberSquad escalation, user
**IAM response template:**
```
Password reset scope:
- Primary accounts: Specops self-service (specops.yourcompany.com) or CyberSquad helpdesk module
- Secondary accounts: manual process — CyberSquad cannot self-service these
- Ghost accounts: manual process — escalate to PaLM team
- Service accounts: Arcon PAM rotation (do not manually reset PAM-vaulted accounts)

If Specops is not working for primary account: verify account type, verify Specops agent is active.
```
