# CONSULTATION-TEMPLATES.md — Per-Team IAM Consultation Patterns
# One section per team. Use as context when prepping for meetings or responding to requests.
# Claude Code uses these to calibrate language, depth, and output format per audience.

---

## How to use
In SESSION.md, set AUDIENCE to the team name.
Claude loads this file and uses the relevant section to calibrate:
- Technical depth of explanation
- What they care about (their lens)
- What IAM needs from them
- Output format that works for them

---

## SECURITY OPERATIONS (SecOps / SOC)

**Their lens**: Threat detection, incident response, alert triage, SIEM correlation
**IAM's role for them**: Decode identity-based alerts, confirm legitimate vs anomalous auth, provide account context, advise on containment

**Common asks they bring you**:
- "We're seeing anomalous auth from account X — is this legitimate?"
- "AD event ID [x] is flooding the SIEM — what does it mean?"
- "We think a service account is compromised — what's the blast radius?"
- "Silverfort flagged lateral movement — which accounts and systems are involved?"

**What you give them**:
- Account context (type, owner, last legitimate use, entitlements)
- Auth flow explanation (what the account should be doing vs what it is doing)
- Containment steps (which IAM tool to use, what action, what to preserve for forensics)
- Log query for SIEM (specific event IDs, fields, time window)
- IAM control gap that enabled this (feeding into gap register)

**Language calibration**: Technical but security-focused. They know AD event IDs, LDAP, SIEM queries. Skip IAM process — go straight to the auth flow and the threat.

**Claude prompt pattern**:
"Read CONTEXT.md and QUICK-REF.md.
SecOps escalation: [symptom].
Account involved: [account name/type].
Give me: account context, likely auth flow, containment steps using our IAM tools,
SIEM query for Google SecOps, and the IAM control gap this exploited."

---

## SERVER TEAM (Infrastructure / Windows / Linux)

**Their lens**: Server availability, AD connectivity, GPO application, service account auth
**IAM's role for them**: Resolve AD auth issues, explain GPO impact, provision/fix service accounts, advise on domain join

**Common asks they bring you**:
- "Service account [X] can't authenticate to [server] — access denied"
- "GPO is blocking [application] on [servers] — can we exempt it?"
- "Server is not domain joined — how do we handle identity for it?"
- "Kerberos errors on [server] — what's wrong?"
- "LAPS / local admin account is locked — how do we reset?"

**What you give them**:
- Step-by-step diagnostic (AD auth path for their specific scenario)
- Exact PowerShell to run on their end to collect evidence
- Arcon PAM vault check (is the service account vaulted? when was password last rotated?)
- GPO analysis (which GPO is applying, why, what the exemption process is)
- Non-domain-joined server guidance (Silverfort agent, local account standards, PAM enrollment)

**Language calibration**: Technical, Windows-fluent. They know PowerShell, Event Viewer, services. Avoid governance language — focus on the technical fix and what they need to do.

**Claude prompt pattern**:
"Read CONTEXT.md and QUICK-REF.md.
Server team escalation: [symptom]. Server: [name/OS/domain joined: Y/N].
Service account: [name/type].
Give me: diagnostic steps for the server team (PowerShell commands they can run),
what I need to check on the IAM side (AD, Arcon PAM, GPO), and the resolution path."

---

## END USER COMPUTING (EUC / Desktop / Helpdesk)

**Their lens**: User productivity, workstation issues, password resets, application access
**IAM's role for them**: Resolve auth failures, EPM elevation issues, Specops/password issues, Autopilot identity

**Common asks they bring you**:
- "User can't log in — account locked or disabled?"
- "EPM is blocking [application] — user needs elevation"
- "Password reset isn't working through Specops"
- "Autopilot machine isn't picking up the user's profile / policies"
- "User has wrong licenses or groups after rebadging"

**What you give them**:
- Account status check (AD, Entra, Okta — is account enabled, licensed, synced?)
- Specops scope clarification (primary accounts only — what to do for secondary/ghost)
- Arcon EPM: is the application whitelisted? Is an elevation workflow configured?
- Autopilot: Entra join vs hybrid join — which GPOs apply, which CA policies apply
- Rebadge 30-day window — explain the old/new account overlap, what's expected

**Language calibration**: Non-IAM technical. Explain in user-impact terms. Give them exact steps. Avoid regulatory language entirely.

**Claude prompt pattern**:
"Read CONTEXT.md.
EUC escalation: [symptom]. User: [OpCo / account type]. Workstation: [domain joined / Autopilot / MacOS].
Give me: account status diagnostic steps, resolution path in plain language,
and any known limitation of our current toolset (e.g., Specops scope)."

---

## GOVERNANCE TEAM

**Their lens**: Policy compliance, control evidence, audit readiness, policy exceptions
**IAM's role for them**: Provide control evidence, explain IAM policy positions, support exception process, flag policy gaps

**Common asks they bring you**:
- "Auditors are asking for evidence of [control X] — can you provide?"
- "We need a list of all privileged accounts for the access review"
- "Policy exception requested for [team] to have local admin — what's the IAM position?"
- "We're updating the IAM policy — can you review section [X]?"

**What you give them**:
- Evidence artifacts (exports, screenshots, command outputs) tied to specific NIST/NYDFS controls
- Gap register entries relevant to their audit scope
- IAM position statement on policy exceptions (with risk rating and mitigating controls)
- Reg/policy gap citation if a requested exception would create a compliance breach

**Language calibration**: Governance-fluent. They understand control IDs, audit evidence, policy language. Use NIST/NYDFS control references directly. Format output as evidence packages.

**Claude prompt pattern**:
"Read CONTEXT.md, QUICK-REF.md, and FINDING_FORMAT.md.
Governance request: [what they need].
Provide: relevant control IDs, evidence checklist for this control,
current gap status from our gap register, and any policy implications."

---

## RISK ASSESSMENT TEAM

**Their lens**: Risk quantification, inherent vs residual risk, risk acceptance, risk register
**IAM's role for them**: Rate IAM control gaps as risks, provide likelihood + impact, recommend mitigating controls

**Common asks they bring you**:
- "We're doing a risk assessment for [application/project] — what are the IAM risks?"
- "Can you rate the residual risk of [gap X] if we accept it?"
- "We're onboarding a vendor — what identity risks should we flag?"
- "What's the IAM risk posture for [OpCo] right now?"

**What you give them**:
- Risk statement per gap (inherent risk, current controls, residual risk, mitigating controls)
- NIST/NYDFS control mapping for each risk
- Likelihood and impact rationale tied to our specific environment
- Recommendation on risk acceptance vs remediation

**Language calibration**: Risk framework language. They think in likelihood × impact. Give them structured risk statements they can put directly into a risk register.

**Claude prompt pattern**:
"Read CONTEXT.md and QUICK-REF.md.
Risk assessment request: [scope / application / project].
Identify IAM risks in our environment relevant to this scope.
For each risk: inherent risk rating, current controls in place, residual risk rating,
mitigating controls recommended, NIST/NYDFS control reference."

---

## COMPLIANCE TEAM

**Their lens**: Regulatory requirements, exam readiness, regulatory citations, remediation evidence
**IAM's role for them**: Map IAM controls to regulations, provide evidence for exams, flag non-compliance

**Common asks they bring you**:
- "NYDFS exam is coming — are we compliant with §500.7 and §500.12?"
- "Regulators asked about our privileged access controls — what do we tell them?"
- "PCI QSA wants evidence of Requirement 8 controls — what do we have?"
- "We got a finding from the last exam — what's the remediation status?"

**What you give them**:
- Compliance posture per regulation section (compliant / partial / non-compliant)
- Evidence artifacts tied to each control
- Gap register entries relevant to the regulation
- Remediation status and timeline for open findings

**Language calibration**: Regulatory language. Be precise — §500.7, AC-2, Req 8.6. They will use your language verbatim in regulatory responses. Accuracy over simplification.

**Claude prompt pattern**:
"Read CONTEXT.md and QUICK-REF.md.
Compliance request: [regulation] [section/control].
Provide: our current compliance posture, available evidence, open gaps with severity,
remediation status, and a draft regulatory response narrative."

---

## CYBER THREAT INTELLIGENCE (CTI)

**Their lens**: Threat actors, TTPs, IOCs, attack patterns, identity-based attack paths
**IAM's role for them**: Map TTPs to identity attack surface, advise on detection, harden against specific threats

**Common asks they bring you**:
- "We have IOCs for account [X] — what's the identity blast radius?"
- "Threat actor using Golden Ticket / Pass-the-Hash / Kerberoasting — are we vulnerable?"
- "We're seeing DCSync activity — what does that mean in our AD environment?"
- "Lateral movement from compromised account — map the access paths"

**What you give them**:
- Identity blast radius (which accounts, groups, systems are reachable from compromised identity)
- Specific vulnerability assessment for the TTP in our environment (e.g., Kerberoastable accounts)
- Detection guidance (specific SIEM queries for Google SecOps, Datadog event IDs)
- Hardening recommendations mapped to the specific TTP

**Language calibration**: Threat-fluent. Use MITRE ATT&CK references where relevant. They understand Kerberos attacks, LDAP enumeration, DCSync. Go deep technically.

**Claude prompt pattern**:
"Read CONTEXT.md and QUICK-REF.md.
CTI request: [TTP or IOC or threat scenario].
In our specific environment (multi-forest AD, Okta, Arcon PAM, Silverfort):
1. Are we vulnerable to this TTP? Where specifically?
2. What is the blast radius if [account type] is compromised?
3. What SIEM queries detect this in Google SecOps (event IDs, fields)?
4. What IAM hardening steps reduce exposure?"

---

## APPLICATION DEVELOPERS

**Their lens**: App functionality, auth integration, service account access, API connections
**IAM's role for them**: Provide service accounts, guide SAML/OIDC/SCIM integration, enforce IAM standards in app design

**Common asks they bring you**:
- "We need a service account for [application] — how do we get one?"
- "We're integrating with Okta/Entra — what's the federation pattern?"
- "Our app uses SCIM — how do we set it up?"
- "We need to pull credentials from PAM vault programmatically — how?"
- "Access denied error from AD/LDAP — what permissions does the service account need?"

**What you give them**:
- Service account provisioning requirements (naming convention, type, PAM enrollment mandatory)
- SAML vs OIDC guidance for their app type (legacy = SiteMinder/SAML, modern = Entra/OIDC)
- SCIM provisioning setup path (Okta SCIM vs Entra SCIM vs OIG fulfiller)
- Arcon PAM API integration guide for credential retrieval
- Least privilege principle applied to their specific request (AC-6)
- SDLC requirements: no hardcoded credentials, code review, change management

**Language calibration**: Developer-fluent. They know OAuth, SAML, SCIM, REST APIs. Avoid process bureaucracy — give them the technical pattern and what they must not do (hardcoded creds, shared accounts).

**Claude prompt pattern**:
"Read CONTEXT.md and QUICK-REF.md.
Developer request: [what they're building / integrating].
Application: [name / APM# if known] / [legacy | modern cloud-native].
Provide: recommended IAM integration pattern, service account requirements if needed,
PAM API guidance if needed, SDLC requirements they must meet, and any IAM risks in their design."

---

## ENTERPRISE ARCHITECTS (EA) & SOLUTION ARCHITECTS (SA)

**Their lens**: Architecture decisions, technology standards, tool consolidation, future state design
**IAM's role for them**: IAM architecture position, identity integration patterns, tool capability boundaries, strategic gaps

**Common asks they bring you**:
- "We're evaluating [new tool] — what are the IAM implications?"
- "We're migrating [app] to cloud — what changes for identity?"
- "We want to consolidate [tool A] and [tool B] — is that feasible?"
- "What's the target state IAM architecture?"
- "New vendor onboarding — what identity standards must they meet?"

**What you give them**:
- IAM architecture position statement for their scenario
- Integration pattern (how the new tool fits in the existing stack)
- Identity risks in the proposed architecture
- IAM requirements the architecture must satisfy (controls, not preferences)
- Strategic alignment with known initiatives (OIG stabilization, Okta→Entra migration, EPM expansion)

**Language calibration**: Architecture-fluent. Patterns, principles, trade-offs, non-functional requirements. Connect to business outcomes and regulatory requirements. They think in 3-5 year horizons.

**Claude prompt pattern**:
"Read CONTEXT.md and QUICK-REF.md.
Architecture consultation: [scenario / proposal].
Provide: IAM architecture position, how this fits (or conflicts with) our current stack,
identity risks in the proposal, IAM requirements that must be met,
and alignment with our known strategic initiatives."

---

## PRINCIPALS & LEADERSHIP (Director, VP, CISO)

**Their lens**: Risk posture, regulatory exposure, resource allocation, program maturity, business impact
**IAM's role for them**: Translate IAM complexity into risk and business language, provide status on key initiatives

**Common asks they bring you**:
- "What's our IAM risk posture right now?"
- "Are we ready for the NYDFS exam?"
- "Why is [initiative] taking so long?"
- "What do we need to fix first?"
- "How does [incident] affect our compliance posture?"

**What you give them**:
- Maturity scorecard (pillar-level, not tool-level)
- Top 3-5 risks with business impact in plain language
- Regulatory exposure summary (not compliant with X, Y, Z — exam risk: high/medium/low)
- Initiative status tied to risk reduction
- Resource/dependency blockers framed as risk

**Language calibration**: Executive language. No tool names in the first paragraph. Lead with risk and impact. Regulations as business exposure, not technical controls. One page max for the summary; detail in the appendix.

**Claude prompt pattern**:
"Read CONTEXT.md and QUICK-REF.md.
Leadership briefing: [topic].
Audience: [Director / VP / CISO].
Produce: executive summary (3-5 sentences, business language, risk-first),
current status with RAG rating, top risks, recommended decisions needed,
and a one-page written brief I can send or present."
