# MEETING-TEMPLATE.md — IAM Meeting Notes Template
# Use for: all formal IAM meetings, consultation sessions, CAB discussions, stakeholder briefings

## Meeting Record
```
Meeting: [title]
Date: [DATE TIME]
Attendees: [list with roles/teams]
Facilitator: IAM Senior Lead Engineer
Type: [Consultation / CAB Pre-review / Incident debrief / Stakeholder briefing / Team sync]
ServiceNow ref: [INC/CHG/PRB number if applicable]

---

## Purpose
[One sentence — what this meeting needed to decide or communicate]

## Key discussion points
1. [Point with context — not just bullet points. What was said and by whom if contentious]
2.
3.

## Decisions made
| Decision | Made by | Rationale |
|---------|---------|-----------|
| [decision] | [name/role] | [why — evidence-based where possible] |

## Action items
| Action | Owner | Due date | ServiceNow ticket | Status |
|--------|-------|---------|-----------------|--------|
| [action] | [name] | [date] | [INC/SR/CHG#] | OPEN |

## IAM position stated
[The IAM recommendation or stance taken in this meeting — document even if not accepted]
[Reg/policy basis for the position: NYDFS §XXX / NIST ctrl / enterprise policy]

## Disagreements / unresolved items
[Document pushback received and from whom — this is the political record]
[Was the IAM position accepted, overridden, or deferred?]

## Follow-up required
[What needs to happen before next meeting or before decision is finalized]

## Confluence
[Post meeting notes to: IAM Space > [pillar] > Meeting Notes > [DATE]]
```
