# ESCALATION-RCA.md — Master Escalation & RCA Template
# Use for all P1/P2 escalations and any complex multi-day problem.
# Claude Code uses this as the output structure for every high-severity escalation.
# Copy completed version → ServiceNow Problem record + Confluence page.

---

## INTAKE (fill in when escalation arrives — 5 minutes)

```
ESCALATION ID:    ESC-[YYYY-MM-DD]-[seq]
RECEIVED:         [datetime]
REPORTED BY:      [team / person]
SEVERITY:         [ P1 | P2 | P3 ]
TOOLS INVOLVED:   [list all IAM tools implicated]
SYMPTOM:          [one sentence — what the reporter says is happening]
BUSINESS IMPACT:  [who is affected and how many users/systems]
ACTIVE INCIDENT:  [ Yes — INC#[xxx] | No ]
```

---

## PHASE 1 — TRIAGE (Claude Code assisted — ~15 minutes)

### 1.1 Symptom Decomposition
Claude prompt: "Read CONTEXT.md and QUICK-REF.md. Given this symptom: [paste symptom].
List every IAM tool that could be the source or a contributing factor. For each, list
the first diagnostic command or check I should run."

Tools to check (auto-populated by Claude based on symptom):
- [ ] [Tool 1]: [first check]
- [ ] [Tool 2]: [first check]
- [ ] [Tool 3]: [first check]

### 1.2 Scope Confirmation
- Affected OpCo(s): [ AM | HS | MS | All ]
- Identity type(s): [ Human | NHI | Both ]
- Account type(s): [ Primary | Secondary | Ghost | Service | gMSA | RPA ]
- Environment: [ Core | PCI | DMZ | Cloud | All ]
- # affected: [number or estimate]

---

## PHASE 2 — INVESTIGATION (Claude Code assisted — structured)

### 2.1 Evidence Collection Log
| Time | Tool | Command / Action | Output summary | Implication |
|------|------|-----------------|----------------|-------------|
| | | | | |

### 2.2 Timeline Reconstruction
| Time | Event | Source | Confirmed? |
|------|-------|--------|-----------|
| | [First known event] | [log / ticket / report] | [ Y / N ] |
| | | | |

### 2.3 Hypothesis Log
| # | Hypothesis | Evidence for | Evidence against | Status |
|---|-----------|-------------|-----------------|--------|
| 1 | | | | [ Active / Ruled out / Confirmed ] |

---

## PHASE 3 — ROOT CAUSE ANALYSIS

### 3.1 Immediate Cause
What directly caused the symptom. Specific — tool, config, account, script.

### 3.2 Contributing Factors
What made this possible or worse. Process gaps, tool limitations, missing controls.

### 3.3 Root Cause (5-Why)
Why 1: [why did the immediate cause occur?]
Why 2: [why did that condition exist?]
Why 3: [why was that not prevented?]
Why 4: [why was that not detected?]
Why 5: [what is the systemic root cause?]

**Root cause statement**: [one clear sentence — this becomes the Problem record root cause]

### 3.4 Regulatory & Policy Implications
(Reference QUICK-REF.md Section 6 for quick lookup)
| Framework | Control | Implication |
|-----------|---------|-------------|
| | | |

---

## PHASE 4 — RESOLUTION

### 4.1 Tactical Fix (what was done to restore service)
Steps taken:
1.
2.
3.

Verified by: [who confirmed resolution]
Verified at: [datetime]
ServiceNow resolution note: [copy-paste ready — 2-3 sentences max]

### 4.2 Immediate Remediation (prevent recurrence short-term)
| Action | Owner | Due | Status |
|--------|-------|-----|--------|
| | | | |

### 4.3 Strategic Recommendation (long-term fix)
What the permanent fix looks like. Link to roadmap initiative or create new one.

| Recommendation | Linked initiative | Owner | Timeline |
|----------------|------------------|-------|----------|
| | | | |

---

## PHASE 5 — OUTPUTS (what you hand back)

### 5.1 ServiceNow Problem Record
**Short description** (80 chars max):
[copy-paste ready]

**Root cause** (work notes):
[paste Phase 3.3 root cause statement]

**Resolution** (resolution notes):
[paste Phase 4.1 tactical fix steps]

**Known error** (if recurring):
[ Yes — create KE record | No ]

**Change required**:
[ Yes — raise RFC | No ]

### 5.2 Meeting Summary (for stakeholder debrief)
**Incident**: [one sentence]
**Root cause**: [one sentence — non-technical version for directors]
**What we did**: [2-3 sentences]
**What we're doing to prevent recurrence**: [2-3 sentences]
**Open items**: [bullet list]
**Owner for follow-up**: [name]

### 5.3 Confluence Documentation
Page title: [ESC-ID] — [symptom summary]
Parent page: Daily Ops > Escalations > [Year]
Sections: copy phases 1-5 above
Label: escalation, [tool-name], [severity], [opco]

### 5.4 Gap Register Entry
If this escalation revealed a systemic gap, create a finding using FINDING_FORMAT.md.
Finding ID: IAM-[seq]-[tool-code]

---

## Claude Code Prompts for Each Phase

### Phase 1 — Triage
"Read CONTEXT.md and QUICK-REF.md. 
Escalation received: [paste symptom + affected users/systems].
List every IAM tool implicated. For each tool, give me:
1. First diagnostic check to run
2. Most likely failure mode based on our environment
3. Which other team I should loop in and why"

### Phase 2 — Investigation
"Read CONTEXT.md and QUICK-REF.md.
Here is what I found so far: [paste evidence collection log].
Given this environment, what are my remaining hypotheses?
What additional evidence do I need to rule each one in or out?
List exact commands or API calls for each."

### Phase 3 — RCA
"Read CONTEXT.md and QUICK-REF.md.
Here is the full evidence: [paste timeline + hypothesis log].
Confirmed root cause: [paste 3.1].
Complete a 5-Why analysis.
Map the root cause to NIST 800-53 and NYDFS Part 500 controls.
Identify which enterprise policies were violated.
Draft a gap register entry in FINDING_FORMAT."

### Phase 4 — Outputs
"Read CONTEXT.md.
Here is the completed RCA: [paste phases 1-3].
Draft the following:
1. ServiceNow Problem record fields (short desc, root cause, resolution, known error decision)
2. Non-technical meeting summary for director-level audience
3. Confluence page draft using our standard format
4. Strategic recommendation linked to our known gap register"
