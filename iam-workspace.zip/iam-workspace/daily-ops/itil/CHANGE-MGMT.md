# CHANGE-MGMT.md — IAM Change Management
# Use for: CAB preparation, RFC creation, change review, post-change verification

## IAM Change Standards

### Change categories that REQUIRE IAM pre-CAB review
1. Any change to AD trust relationships or forest topology
2. Conditional Access policy changes (create, modify, delete)
3. Okta policy, integration, or sync agent changes
4. Arcon PAM vault configuration or access changes
5. Arcon EPM policy changes
6. ADConnect sync rule or attribute filter changes
7. NetIQ / IG workflow or connector changes
8. GPO creation, modification, or linking
9. Service account creation, modification, or deletion
10. Certificate changes (Keyfactor, CA certificates)

### Change risk classification
| Risk | Change type | Approval required |
|------|------------|------------------|
| Standard | Pre-approved, repeatable, documented | No CAB |
| Normal-Low | Minor config change, 1 system | IAM Lead + CAB |
| Normal-High | Multiple systems, auth path | IAM Lead + Architect + CAB |
| Emergency | P1/P2 resolution only | IAM Lead + Director + post-CAB |

## RFC Template (IAM-specific fields)
```
Change title: [clear, specific — "Disable RC4 Kerberos encryption on [domain] DCs"]
Change type: [Normal-Low / Normal-High / Standard / Emergency]
Requestor: [name + team]
IAM pillar: [FID / PPM / PaLM / IAC / Cross-pillar]
IAM pre-CAB reviewer: IAM Senior Lead Engineer

## What this change actually does
[Plain English — the real IAM impact, not the technical spec]

## Tools/systems affected
[Specific: which AD domain, which Okta policy, which CA policy ID, etc.]

## Identity types affected
[Human: primary/secondary/ghost | NHI: service account/gMSA/RPA | Both]

## OpCo scope
[AM / HS / MS / All / PCI / DMZ]

## Regulatory exposure
[NYDFS §XXX / NIST ctrl / PCI Req — if this change relates to a control]

## Test plan
[Specific: which non-prod environment, what test cases, who validates, what is pass criteria]

## Rollback plan
[Specific steps — not "reverse the change". Who executes? In how long?]
[Is rollback itself risky? If yes, state why and what the mitigation is]

## Communication plan
[Who is notified if this change causes an outage? At what point?]
[CyberSquad briefed? Y/N — runbook updated? Y/N]

## Post-change verification
[Specific: what checks confirm the change succeeded without side effects]
[Time window for monitoring: e.g., "monitor auth error rate in Google SecOps for 2 hours"]
```

## IAM Pre-CAB Checklist
Before presenting to CAB, IAM pre-CAB reviewer checks:
- [ ] GTI CVE check for tools being changed
- [ ] SQLite incident history query — similar changes causing incidents
- [ ] Rollback plan is specific and executable
- [ ] Test evidence from non-prod environment
- [ ] Communication plan includes CyberSquad briefing
- [ ] Monitoring window and success criteria defined
- [ ] STRIDE threat model for security-impacting changes

## Post-Change Verification Script
```powershell
# Run after every AD-related change
# 1. Check replication health
repadmin /replsummary
# 2. Check auth is working
Test-ComputerSecureChannel -Verbose
# 3. Check ADConnect sync status
Get-ADSyncConnectorRunStatus
# 4. Check Silverfort agent status on affected DCs
# (via Silverfort admin console)
# 5. Monitor Google SecOps for 30 minutes post-change — auth failure spike?
```
