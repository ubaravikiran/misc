# PROBLEM-MGMT.md — IAM Problem Management
# Use for: chronic issue investigation, root cause analysis, known error creation

## Problem Management in IAM Context
Problems are raised when:
1. An incident recurs 3+ times (same root cause pattern)
2. A workaround exists but no permanent fix — Known Error
3. A systemic gap is identified that generates multiple incidents
4. Post-incident analysis reveals an architectural or process failure

## Problem Record Template
```
Problem number: PRB-[XXXX]
Title: [specific — "Arcon PAM vault sync lag causes service account auth failures during rotation window"]
Linked incidents: [INC-XXXX, INC-XXXX, INC-XXXX]
Affected pillar: [FID / PPM / PaLM / IAC / Cross-pillar]
Status: [Under Investigation / Root Cause Identified / Known Error / Closed]

## Problem statement
[What is the recurring failure — specific, not vague. Who is affected, how often, what is the business impact.]

## Evidence collected
[Specific: log excerpts, timeline, ticket numbers, command outputs]

## Root cause (5-Why)
Why 1: [immediate cause]
Why 2: [why that condition existed]
Why 3: [why that was not prevented]
Why 4: [why that was not detected]
Why 5: [systemic root cause]

Root cause statement: [one clear sentence — this goes into the ServiceNow root_cause field]

## Known workaround (if root cause not yet fixed)
[Specific steps for CyberSquad / L2 team to follow — update runbook reference]
Known Error: [YES — KE created / NO]

## Permanent fix
[What the real fix is — tactical and strategic]
SAFe backlog: [Epic/Feature/Story + PI placement]
Owner: [team + person]
Target: [date or PI]

## Regulatory/policy implications
[Does this problem represent a compliance gap? NYDFS §XXX / NIST ctrl / PCI Req]
Gap register: [IAM-XXX created / N/A]
```

## Known Error Registry (running list in this file)
| KE-ID | Problem | Workaround | Status |
|-------|---------|-----------|--------|
| KE-001 | IG not enterprise-functional | Manual access reviews | Open — vendor PS engagement |
| KE-002 | Okta system log not in SIEM | Manual Okta log review for incidents | Open — pipeline build needed |
| KE-003 | Service account → CMDB mapping missing | Manual PPM team maintained list | Open — CMDB enhancement needed |
| KE-004 | Specops scope = primary accounts only | Manual process for secondary accounts | Open — architecture decision needed |
