#!/bin/bash
# =============================================================================
# bootstrap.sh — IAM Workspace Setup
# Run from WSL2: bash /mnt/d/mrrobot/bootstrap.sh
# Creates complete workspace at /mnt/d/mrrobot/ (Windows: D:\mrrobot\)
# =============================================================================
set -euo pipefail

WORKSPACE="/mnt/d/mrrobot"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BLUE='\033[0;34m'; CYAN='\033[0;36m'; NC='\033[0m'

info()    { echo -e "${BLUE}[INFO]${NC}    $1"; }
success() { echo -e "${GREEN}[OK]${NC}      $1"; }
warn()    { echo -e "${YELLOW}[WARN]${NC}    $1"; }
error()   { echo -e "${RED}[ERROR]${NC}   $1"; exit 1; }
section() { echo -e "\n${CYAN}══ $1 ══${NC}"; }

echo -e "${CYAN}"
echo "  ██╗ █████╗ ███╗   ███╗    ██╗    ██╗ ██████╗ ██████╗ ██╗  ██╗███████╗██████╗  █████╗  ██████╗ "
echo "  ██║██╔══██╗████╗ ████║    ██║    ██║██╔═══██╗██╔══██╗██║ ██╔╝██╔════╝██╔══██╗██╔══██╗██╔════╝ "
echo "  ██║███████║██╔████╔██║    ██║ █╗ ██║██║   ██║██████╔╝█████╔╝ ███████╗██████╔╝███████║██║      "
echo "  ██║██╔══██║██║╚██╔╝██║    ██║███╗██║██║   ██║██╔══██╗██╔═██╗ ╚════██║██╔═══╝ ██╔══██║██║      "
echo "  ██║██║  ██║██║ ╚═╝ ██║    ╚███╔███╔╝╚██████╔╝██║  ██║██║  ██╗███████║██║     ██║  ██║╚██████╗ "
echo "  ╚═╝╚═╝  ╚═╝╚═╝     ╚═╝     ╚══╝╚══╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝╚═╝     ╚═╝  ╚═╝ ╚═════╝"
echo -e "${NC}"
echo "  IAM Workspace Bootstrap — WSL2 → D:\\mrrobot\\"
echo "  Version: 1.0.0 | $(date '+%Y-%m-%d %H:%M:%S')"
echo ""

# =============================================================================
# PRE-FLIGHT CHECKS
# =============================================================================
section "Pre-flight checks"

[[ -d /mnt/d ]] || error "D: drive not mounted at /mnt/d. Check WSL2: sudo mkdir -p /mnt/d && sudo mount -t drvfs D: /mnt/d"
success "D: drive accessible at /mnt/d"

command -v op  >/dev/null 2>&1 && success "1Password CLI (op) found" || warn "1Password CLI not found — MCP secrets won't resolve. Install: https://developer.1password.com/docs/cli/"
command -v node >/dev/null 2>&1 && success "Node.js found: $(node --version)" || warn "Node.js not found — MCP servers via npx will fail"
command -v python3 >/dev/null 2>&1 && success "Python3 found: $(python3 --version)" || warn "Python3 not found — db-setup.py and db-analyze.py require it"

# =============================================================================
# BACKUP EXISTING WORKSPACE
# =============================================================================
section "Workspace preparation"

if [[ -d "$WORKSPACE" ]] && [[ -f "$WORKSPACE/CLAUDE.md" ]]; then
    BACKUP="${WORKSPACE}_backup_${TIMESTAMP}"
    warn "Existing workspace found with CLAUDE.md — creating backup"
    cp -r "$WORKSPACE" "$BACKUP"
    success "Backup: $BACKUP"
else
    info "No existing workspace detected — clean install"
fi

# =============================================================================
# DIRECTORY STRUCTURE
# =============================================================================
section "Creating directory structure"

dirs=(
    "$WORKSPACE/.claude/commands"
    "$WORKSPACE/.claude/agents/ics"
    "$WORKSPACE/.claude/agents/ctd"
    "$WORKSPACE/.claude/agents/ise"
    "$WORKSPACE/.claude/agents/rise"
    "$WORKSPACE/.claude/agents/special"
    "$WORKSPACE/assessment/pillars"
    "$WORKSPACE/assessment/evidence/ad"
    "$WORKSPACE/assessment/evidence/entra"
    "$WORKSPACE/assessment/evidence/okta"
    "$WORKSPACE/assessment/evidence/arcon-pam"
    "$WORKSPACE/assessment/evidence/arcon-epm"
    "$WORKSPACE/assessment/evidence/netiq"
    "$WORKSPACE/assessment/evidence/ig"
    "$WORKSPACE/assessment/evidence/specops"
    "$WORKSPACE/assessment/evidence/siteminder"
    "$WORKSPACE/assessment/evidence/radiant-logic"
    "$WORKSPACE/assessment/evidence/silverfort"
    "$WORKSPACE/assessment/evidence/groupid"
    "$WORKSPACE/assessment/findings"
    "$WORKSPACE/assessment/outputs/confluence-pages"
    "$WORKSPACE/daily-ops/itil"
    "$WORKSPACE/daily-ops/consultation-templates"
    "$WORKSPACE/daily-ops/runbooks"
    "$WORKSPACE/daily-ops/meeting-notes"
    "$WORKSPACE/daily-ops/servicenow"
    "$WORKSPACE/knowledge-base/regs-raw"
    "$WORKSPACE/knowledge-base/policies-raw"
    "$WORKSPACE/knowledge-base/vendor-summaries"
    "$WORKSPACE/knowledge-base/skills-archive"
    "$WORKSPACE/knowledge-base/enterprise-policies"
    "$WORKSPACE/data"
)

for d in "${dirs[@]}"; do
    mkdir -p "$d"
done

success "$(echo "${#dirs[@]}") directories created"

# =============================================================================
# .claude/settings.json — MCP CONFIG WITH 1PASSWORD
# =============================================================================
section "Writing MCP configuration (.claude/settings.json)"

cat > "$WORKSPACE/.claude/settings.json" << 'SETTINGS_EOF'
{
  "_comment_1password": "op run resolves op://VAULT/ITEM/FIELD references automatically in env vars",
  "_comment_setup": "Replace VAULT_NAME, item paths, and verify MCP package names match your installed versions",
  "_comment_gti": "GTI is loaded in every security session — see CLAUDE.md GTI_ALWAYS_ON section",

  "mcpServers": {

    "confluence": {
      "_comment": "Atlassian Confluence Cloud MCP — https://[company].atlassian.net",
      "command": "op",
      "args": [
        "run",
        "--no-masking",
        "--",
        "npx",
        "-y",
        "@anthropic-labs/mcp-server-confluence"
      ],
      "env": {
        "CONFLUENCE_URL":       "op://VAULT_NAME/Confluence/url",
        "CONFLUENCE_EMAIL":     "op://VAULT_NAME/Confluence/email",
        "CONFLUENCE_API_TOKEN": "op://VAULT_NAME/Confluence/api-token",
        "_comment_space":       "Optional: restrict to specific Confluence space key",
        "CONFLUENCE_SPACE_KEY": "op://VAULT_NAME/Confluence/space-key"
      }
    },

    "datadog": {
      "_comment": "Datadog MCP — metrics, logs, monitors, dashboards",
      "command": "op",
      "args": [
        "run",
        "--no-masking",
        "--",
        "npx",
        "-y",
        "@datadog/datadog-mcp-server"
      ],
      "env": {
        "DD_API_KEY":  "op://VAULT_NAME/Datadog/api-key",
        "DD_APP_KEY":  "op://VAULT_NAME/Datadog/app-key",
        "DD_SITE":     "datadoghq.com",
        "_comment_site": "Change DD_SITE if your org uses datadoghq.eu or other region"
      }
    },

    "google-threat-intelligence": {
      "_comment": "GTI — Google Threat Intelligence (formerly Mandiant + VirusTotal Enterprise)",
      "_comment_package": "Verify the exact package name matches your current working GTI MCP install",
      "command": "op",
      "args": [
        "run",
        "--no-masking",
        "--",
        "npx",
        "-y",
        "TODO_REPLACE_WITH_YOUR_GTI_MCP_PACKAGE"
      ],
      "env": {
        "GTI_API_KEY":        "op://VAULT_NAME/GoogleThreatIntelligence/api-key",
        "GOOGLE_API_KEY":     "op://VAULT_NAME/GoogleThreatIntelligence/google-api-key",
        "VT_API_KEY":         "op://VAULT_NAME/GoogleThreatIntelligence/virustotal-api-key",
        "_comment_keys":      "GTI may use one or more of these key types — keep only what applies"
      }
    }

  },

  "_comment_op_read_alternative": "If op run does not work, use the wrapper script pattern below instead",
  "_comment_wrapper": "See data/mcp-wrapper.sh for the op read fallback approach"
}
SETTINGS_EOF

success ".claude/settings.json written"

# =============================================================================
# OP READ WRAPPER SCRIPT (fallback if op run not working)
# =============================================================================
section "Writing 1Password wrapper scripts"

cat > "$WORKSPACE/data/mcp-wrapper-confluence.sh" << 'WRAPPER_EOF'
#!/bin/bash
# mcp-wrapper-confluence.sh
# Fallback if op run pattern doesn't work.
# Usage in settings.json: "command": "/mnt/d/mrrobot/data/mcp-wrapper-confluence.sh"
# Remove "args" entry, remove "env" section.
export CONFLUENCE_URL=$(op read "op://VAULT_NAME/Confluence/url")
export CONFLUENCE_EMAIL=$(op read "op://VAULT_NAME/Confluence/email")
export CONFLUENCE_API_TOKEN=$(op read "op://VAULT_NAME/Confluence/api-token")
exec npx -y @anthropic-labs/mcp-server-confluence "$@"
WRAPPER_EOF

cat > "$WORKSPACE/data/mcp-wrapper-datadog.sh" << 'WRAPPER_EOF'
#!/bin/bash
# mcp-wrapper-datadog.sh
export DD_API_KEY=$(op read "op://VAULT_NAME/Datadog/api-key")
export DD_APP_KEY=$(op read "op://VAULT_NAME/Datadog/app-key")
export DD_SITE="datadoghq.com"
exec npx -y @datadog/datadog-mcp-server "$@"
WRAPPER_EOF

cat > "$WORKSPACE/data/mcp-wrapper-gti.sh" << 'WRAPPER_EOF'
#!/bin/bash
# mcp-wrapper-gti.sh
export GTI_API_KEY=$(op read "op://VAULT_NAME/GoogleThreatIntelligence/api-key")
export VT_API_KEY=$(op read "op://VAULT_NAME/GoogleThreatIntelligence/virustotal-api-key")
exec npx -y TODO_REPLACE_WITH_YOUR_GTI_MCP_PACKAGE "$@"
WRAPPER_EOF

chmod +x "$WORKSPACE/data/mcp-wrapper-confluence.sh"
chmod +x "$WORKSPACE/data/mcp-wrapper-datadog.sh"
chmod +x "$WORKSPACE/data/mcp-wrapper-gti.sh"

success "MCP wrapper scripts written (fallback for op read pattern)"

# =============================================================================
# INSIGHTS-INDEX.md PLACEHOLDER
# =============================================================================
cat > "$WORKSPACE/data/INSIGHTS-INDEX.md" << 'IDX_EOF'
# INSIGHTS-INDEX.md — Metadata only. No ticket data. Safe to commit.
# Generated: NOT YET RUN
# Full data: query iam_* tables in data/iam-servicenow.db

DB_PATH: data/iam-servicenow.db
Last_analyzed: PENDING
Top_pattern: PENDING

Tables: NOT YET GENERATED
  iam_insights:       0 patterns
  iam_change_risks:   0 risky changes
  iam_p1p2_index:     0 P1/P2 incidents
  iam_open_problems:  0 stale problems
  iam_team_activity:  0 teams

NEXT STEP: Place your ServiceNow SQLite export at data/iam-servicenow.db
           then run: python3 data/db-setup.py && python3 data/db-analyze.py
IDX_EOF

success "INSIGHTS-INDEX.md placeholder written"

# =============================================================================
# gap-register.md TEMPLATE
# =============================================================================
cat > "$WORKSPACE/assessment/gap-register.md" << 'GAP_EOF'
# GAP REGISTER — IAM Maturity Assessment
# Living document. Updated after every assessment session or escalation finding.
# Last updated: PENDING

| ID | Tool | Control | Finding (one line) | Severity | NIST | NYDFS | PCI | Owner | Target | Status |
|----|------|---------|-------------------|----------|------|-------|-----|-------|--------|--------|
| IAM-001 | [tool] | [ctrl] | [finding] | [Critical/High/Med/Low] | [ctrl ID] | [§xxx] | [Req x] | [team] | [date] | Open |
GAP_EOF

success "gap-register.md template written"

# =============================================================================
# VENDOR SUMMARIES INDEX
# =============================================================================
cat > "$WORKSPACE/knowledge-base/vendor-summaries/VENDOR-SUMMARIES-INDEX.md" << 'VSI_EOF'
# VENDOR-SUMMARIES-INDEX.md
# Pre-digested vendor reference — load only the relevant one per session (~500 tokens each).
# Raw vendor manuals: vendor-docs-raw/ — access surgically with explicit prompt.

## Status
| File | Status | Notes |
|------|--------|-------|
| microsoft-ad-entra.md | ✓ Built | AD, Entra, ADConnect, GPO, Kerberos |
| okta.md | TODO | |
| arcon-pam-epm.md | TODO | |
| opentext-netiq-ig.md | TODO | IG not OIG |
| siteminder.md | TODO | |
| specops.md | TODO | |
| radiant-logic.md | TODO | |
| silverfort.md | TODO | |
| groupid.md | TODO | |
| keyfactor.md | TODO | |
| google-secops.md | TODO | |
| cortex-xdr-xsoar.md | TODO | |
| microsoft-defender.md | TODO | |
| datadog.md | TODO | |
| servicenow.md | TODO | |
| 1password.md | TODO | |

## How to load in a session
Add to SESSION.md: knowledge-base/vendor-summaries/[tool-name].md
VSI_EOF

success "VENDOR-SUMMARIES-INDEX.md written"

# =============================================================================
# PLACEHOLDER AGENT FILES
# =============================================================================
section "Creating agent placeholder files"

# ICS agents
for agent in manager architect principal fid-engineer ppm-engineer palm-engineer iac-engineer cybersquad; do
    cat > "$WORKSPACE/.claude/agents/ics/${agent}.md" << AGENT_EOF
# ${agent}.md — ICS Agent (placeholder)
# Based on director.md structure.
# TODO: Populate from the agent design specifications in the conversation history.
# Reference: director.md for complete structure template.
AGENT_EOF
done

# CTD agents
for agent in cti secops evm appsec iri; do
    cat > "$WORKSPACE/.claude/agents/ctd/${agent}.md" << AGENT_EOF
# ${agent}.md — CTD Agent (placeholder)
# TODO: Build from CTD org portfolio specifications.
AGENT_EOF
done

# ISE agents
for agent in adp defeng plateng scta soleng; do
    cat > "$WORKSPACE/.claude/agents/ise/${agent}.md" << AGENT_EOF
# ${agent}.md — ISE Agent (placeholder)
# TODO: Build from ISE org portfolio specifications.
AGENT_EOF
done

# RISE agents
for agent in rise eirm-drc enterprise-dr; do
    cat > "$WORKSPACE/.claude/agents/rise/${agent}.md" << AGENT_EOF
# ${agent}.md — RISE/EIRM/DR Agent (placeholder)
# TODO: Build from RISE/EIRM org portfolio specifications.
AGENT_EOF
done

# Special agents
for agent in iam-solution-architect safe-agent threat-model-agent iam-assessment-agent; do
    cat > "$WORKSPACE/.claude/agents/special/${agent}.md" << AGENT_EOF
# ${agent}.md — Special Agent (placeholder)
# TODO: Build from special agent specifications.
AGENT_EOF
done

success "Agent placeholder files created (26 agents)"
info "  Priority to build: ics/architect.md, ics/principal.md, special/threat-model-agent.md, special/safe-agent.md"

# =============================================================================
# SLASH COMMAND PLACEHOLDERS
# =============================================================================
section "Creating slash command placeholders"

for cmd in safe plan email doc brainstorm adr audit analyze; do
    cat > "$WORKSPACE/.claude/commands/${cmd}.md" << CMD_EOF
# /${cmd} — Slash command (placeholder)
# TODO: Build from skill consolidation plan (see conversation history).
CMD_EOF
done

success "Additional slash command placeholders created"

# =============================================================================
# ASSESSMENT PILLAR PLACEHOLDERS
# =============================================================================
for i in "01-directory-services" "02-access-management" "03-pam" "04-identity-admin" "05-identity-governance"; do
    cat > "$WORKSPACE/assessment/pillars/${i}.md" << PIL_EOF
# ${i}.md — Assessment Pillar
# TODO: Build from IAM maturity assessment framework.
# Reference: IAM_Enterprise_Assessment.pdf (117 pages uploaded earlier)
PIL_EOF
done

success "Assessment pillar placeholders created"

# =============================================================================
# ITIL PLACEHOLDERS
# =============================================================================
cat > "$WORKSPACE/daily-ops/itil/CHANGE-MGMT.md" << 'CM_EOF'
# CHANGE-MGMT.md — CAB Prep and RFC Template
# TODO: Build from change management requirements.
# Reference: /cab slash command for automated CAB review.
CM_EOF

cat > "$WORKSPACE/daily-ops/itil/PROBLEM-MGMT.md" << 'PM_EOF'
# PROBLEM-MGMT.md — Problem Record and Known Error Template
# TODO: Build from ITIL problem management requirements.
# Reference: ESCALATION-RCA.md for the problem management workflow.
PM_EOF

success "ITIL template placeholders created"

# =============================================================================
# FINAL VALIDATION
# =============================================================================
section "Validation"

file_count=$(find "$WORKSPACE" -type f | wc -l)
dir_count=$(find "$WORKSPACE" -type d | wc -l)

success "Workspace created at: $WORKSPACE (Windows: D:\\mrrobot\\)"
echo ""
echo "  Files created:       $file_count"
echo "  Directories created: $dir_count"
echo ""

echo -e "${YELLOW}══ NEXT STEPS (in order) ══${NC}"
echo ""
echo "  1. Copy content files into workspace:"
echo "     - CLAUDE.md          → $WORKSPACE/CLAUDE.md"
echo "     - SESSION.md         → $WORKSPACE/SESSION.md"
echo "     - CONTEXT.md         → $WORKSPACE/CONTEXT.md"
echo "     - QUICK-REF.md       → $WORKSPACE/QUICK-REF.md"
echo "     - FINDING_FORMAT.md  → $WORKSPACE/FINDING_FORMAT.md"
echo "     - ESCALATION-RCA.md  → $WORKSPACE/daily-ops/itil/ESCALATION-RCA.md"
echo "     - CONSULTATION-TEMPLATES.md → $WORKSPACE/daily-ops/consultation-templates/"
echo "     - microsoft-ad-entra.md     → $WORKSPACE/knowledge-base/vendor-summaries/"
echo "     - director.md        → $WORKSPACE/.claude/agents/ics/director.md"
echo "     - debate.md          → $WORKSPACE/.claude/commands/debate.md"
echo "     - [all other slash commands from conversation history]"
echo ""
echo "  2. Configure MCP settings:"
echo "     - Edit $WORKSPACE/.claude/settings.json"
echo "     - Replace VAULT_NAME with your 1Password vault name"
echo "     - Replace op://VAULT_NAME/... paths with your actual 1Password item paths"
echo "     - Replace TODO_REPLACE_WITH_YOUR_GTI_MCP_PACKAGE with your GTI package name"
echo "     - Test: cd $WORKSPACE && claude  (should show MCP tools connected)"
echo ""
echo "  3. Set up ServiceNow SQLite DB:"
echo "     - Place your DB at: $WORKSPACE/data/iam-servicenow.db"
echo "     - Run: python3 $WORKSPACE/data/db-setup.py"
echo "     - Run: python3 $WORKSPACE/data/db-analyze.py"
echo ""
echo "  4. Drop policy and reg PDFs:"
echo "     - Enterprise policies → $WORKSPACE/knowledge-base/enterprise-policies/"
echo "     - NIST/NYDFS/PCI PDFs → $WORKSPACE/knowledge-base/regs-raw/"
echo "     - Vendor docs         → appropriate subdirs under knowledge-base/"
echo ""
echo "  5. Build remaining agent files (priority order):"
echo "     - ics/architect.md"
echo "     - ics/principal.md"
echo "     - special/threat-model-agent.md"
echo "     - special/safe-agent.md"
echo "     - ics/fid-engineer.md"
echo "     - [remaining 21 agents]"
echo ""
echo -e "${GREEN}Bootstrap complete. Workspace ready at D:\\mrrobot\\${NC}"
