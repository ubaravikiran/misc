# QUICK-REF.md — IAM Regulatory & Policy Reference Digest
# ~3,000 tokens. Loaded in every session.
# Raw PDFs live in knowledge-base/regs-raw/ — only access surgically when exact language needed.
# Built from: NIST SP 800-53 Rev5, NIST SP 800-63-3, NYDFS Part 500 (Nov 2023), PCI DSS v4.0
# Last rebuilt: [DATE — update when regulations change]

---

## How to use this file
- Daily ops / troubleshooting: cite control IDs when writing RCAs and gap citations
- Assessment: use control IDs to score findings
- Consultation: use plain-English summaries when explaining to non-IAM teams
- Exact text needed: "Load knowledge-base/regs-raw/[file].pdf, find [control/section]"

---

## Section 1 — NIST SP 800-53 Rev5: IAM-Relevant Controls

| Control ID | Name | One-line description | IAM tool(s) | Enterprise policy ref |
|------------|------|----------------------|-------------|----------------------|
| AC-2 | Account Management | Manage information system accounts — creation, activation, modification, review, disabling, removal | AD, Entra, NetIQ, OIG | IAM-POL §[x] |
| AC-2(1) | Automated Account Mgmt | Automate account mgmt processes | NetIQ, OIG | IAM-POL §[x] |
| AC-2(3) | Disable Inactive Accounts | Disable accounts after defined inactivity period | AD, Okta, Entra | IAM-POL §[x] |
| AC-2(7) | Privileged User Accounts | Establish and administer privileged accounts | Arcon PAM, AD | IAM-POL §[x] |
| AC-3 | Access Enforcement | Enforce approved authorizations for logical access | OIG, Okta, CA Policies | IAM-POL §[x] |
| AC-4 | Information Flow Enforcement | Control flow of information between systems | AD trust relationships, PCI/DMZ segmentation | SEC-POL §[x] |
| AC-5 | Separation of Duties | Define SoD, document, enforce | OIG (SoD module), AD | IAM-POL §[x] |
| AC-6 | Least Privilege | Employ least privilege for all functions | Arcon EPM, Arcon PAM, OIG RBAC | IAM-POL §[x] |
| AC-6(1) | Authorize Security Functions | Explicit authorization to access security functions | Arcon PAM | IAM-POL §[x] |
| AC-6(2) | Non-Privileged Access for Non-Security | Separate privileged and non-privileged accounts | AD admin accounts, PAM | IAM-POL §[x] |
| AC-17 | Remote Access | Establish and document remote access policies | VPN + PAM jump, AD | IAM-POL §[x] |
| IA-2 | Identification and Authentication | Uniquely identify and authenticate org users | Okta, CA Policies, Silverfort | IAM-POL §[x] |
| IA-2(1) | MFA — Privileged Accounts | MFA for privileged account network access | Arcon PAM, CA Policies | IAM-POL §[x] |
| IA-2(2) | MFA — Non-Privileged Accounts | MFA for non-privileged account network access | Okta, CA Policies | IAM-POL §[x] |
| IA-4 | Identifier Management | Manage information system identifiers | AD, Entra, OIG | IAM-POL §[x] |
| IA-5 | Authenticator Management | Manage system authenticators (passwords, certs, tokens) | Specops, Keyfactor, Arcon PAM | IAM-POL §[x] |
| IA-5(7) | No Embedded Unencrypted Static Authenticators | No hardcoded credentials in scripts/code | OIG fulfillers, app integrations | SDLC-POL §[x] |
| IA-8 | ID & Auth — Non-Org Users | Identify and authenticate non-org users | Okta federation, SiteMinder | IAM-POL §[x] |
| AU-2 | Event Logging | Define events to be logged | Google SecOps, Datadog, AD audit | LOG-POL §[x] |
| AU-6 | Audit Record Review | Review and analyze audit records | Google SecOps, SIEM alerts | LOG-POL §[x] |
| AU-11 | Audit Record Retention | Retain audit records for defined period | SIEM retention, PAM session recordings | LOG-POL §[x] |
| AU-12 | Audit Record Generation | Generate audit records for defined events | All tools → SIEM | LOG-POL §[x] |
| CM-3 | Configuration Change Control | Authorize, document, and review config changes | CAB, GPO changes, CA policy changes | SDLC-POL §[x] |
| CM-5 | Access Restrictions for Change | Define and document access restrictions for changes | AD, Entra, PAM | SDLC-POL §[x] |
| CM-6 | Configuration Settings | Establish config settings for all IT products | GPO, Okta policies, CA policies | SDLC-POL §[x] |
| CM-7 | Least Functionality | Prohibit or restrict use of functions/ports/protocols | Arcon EPM app whitelisting | SDLC-POL §[x] |
| CM-8 | System Component Inventory | Develop and maintain inventory of system components | CMDB (ServiceNow APM#) | ASSET-POL §[x] |
| PS-4 | Personnel Termination | Disable access upon termination | NetIQ/MyAccess JML, AD | HR-POL §[x] |
| SA-3 | System Development Life Cycle | Manage system using defined SDLC | OIG fulfillers, IAM scripts | SDLC-POL §[x] |
| SA-11 | Developer Testing and Evaluation | Require code review, testing for developer-produced code | OIG fulfillers | SDLC-POL §[x] |
| SC-8 | Transmission Confidentiality | Protect transmitted information | HR feed encryption, LDAP signing | SEC-POL §[x] |
| SC-17 | Public Key Infrastructure | Manage PKI certificates | Keyfactor, Microsoft PKI | SEC-POL §[x] |
| SC-28 | Protection of Information at Rest | Protect stored information | PAM vault encryption, SIEM data | SEC-POL §[x] |
| SI-4 | System Monitoring | Monitor information systems | Silverfort, Datadog, Google SecOps | LOG-POL §[x] |
| SI-12 | Information Management & Retention | Manage and retain information | OIG data retention, entitlement data | DATA-POL §[x] |

---

## Section 2 — NIST SP 800-63-3: Digital Identity (IAL/AAL/FAL)

| Level | Type | Meaning | IAM application |
|-------|------|---------|-----------------|
| IAL1 | Identity Assurance | Self-asserted — no identity proofing | Guest/anonymous access |
| IAL2 | Identity Assurance | Remote or in-person proofing required | Standard employees (Workday/Simplify) |
| IAL3 | Identity Assurance | In-person proofing + supervised | PCI zone / privileged identities |
| AAL1 | Authenticator Assurance | Single factor | Low-risk systems only |
| AAL2 | Authenticator Assurance | MFA required | Standard enterprise (Okta + CA Policies) |
| AAL3 | Authenticator Assurance | Hardware-based MFA | Privileged admin (PAM + FIDO2) |
| FAL1 | Federation Assurance | Basic bearer assertion | Standard SAML/OIDC (Okta, SiteMinder) |
| FAL2 | Federation Assurance | Signed assertion | Sensitive app federations |
| FAL3 | Federation Assurance | Holder-of-key assertion | High-risk federations |

---

## Section 3 — NYDFS 23 NYCRR Part 500 (November 2023 Amendment)

| Section | Title | Requirement (plain English) | IAM tools | Current gap status |
|---------|-------|----------------------------|-----------|-------------------|
| §500.2 | Cybersecurity Program | Maintain a formal cybersecurity program | All IAM tools | IAM maturity assessment is this program |
| §500.3 | Cybersecurity Policy | Written policy reviewed annually | CONTEXT + policies | Policies exist; IAM mapping gaps |
| §500.6 | Audit Trail | Maintain audit trails — 3 years for financial, 5 for cyber events | Google SecOps, Arcon PAM | PAM retention period unconfirmed |
| §500.7 | Access Privileges | Least privilege, MFA for privileged, review non-person accounts | All IAM tools | Multiple open gaps — NHI accounts, EPM coverage |
| §500.12 | MFA | MFA required for all remote access and privileged access | CA Policies, Okta, Arcon PAM | CA policy baseline gaps |
| §500.13 | Data Retention | Limit retention of NPI — dispose when no longer needed | OIG data, AD terminated accounts | No formal retention policy for identity data |
| §500.14 | Training + Monitoring | Monitor authorized users, detect anomalies | Silverfort, Google SecOps, Datadog | Okta logs → SIEM gap; EPM events gap |
| §500.15 | Encryption | Encrypt NPI in transit and at rest | HR feed (Workday/Simplify → NetIQ) | Encryption in transit not formally evidenced |
| §500.16 | Incident Response Plan | Maintain and test IR plan | ServiceNow, Google SecOps | IR plan exists; IAM-specific playbooks needed |

---

## Section 4 — PCI DSS v4.0: Requirements 7 & 8 (IAM-specific)

| Req | Title | Key control | IAM tools | Notes |
|-----|-------|-------------|-----------|-------|
| 7.1 | Limit access to system components | Need-to-know basis | OIG RBAC, AD | OIG not enterprise-active |
| 7.2 | Access control system | Enforce least privilege via ACS | OIG, AD, Arcon PAM | PCI forest — verify segmentation evidence |
| 7.3 | Access is managed via ACS | All access via defined system | OIG (future state) | Currently manual in many areas |
| 8.2 | User IDs and auth management | Unique IDs, no shared accounts | AD, Okta | Ghost account model — must be evidenced |
| 8.3 | Protect individual non-consumer auth | Password complexity, lockout, MFA | Specops, CA Policies | Specops = primary accounts only |
| 8.4 | MFA for CDE access | MFA required for all CDE access | CA Policies, Arcon PAM | PCI forest MFA coverage must be evidenced |
| 8.5 | MFA system security | MFA not susceptible to replay | FIDO2 / phish-resistant | SMS MFA still in use for some — risk |
| 8.6 | Non-person accounts | Managed with policies, reviewed | Arcon PAM, AD | Service account → app mapping missing |

---

## Section 5 — Enterprise Policy Cross-Reference Index
# [TO BE BUILT — run knowledge-build session for each policy export]
# Prompt: "Read [policy file]. Extract: policy name, section, specific requirement,
#          map to NIST 800-53 control ID, NYDFS section, PCI DSS req. Output as table row."

| Policy | Section | Requirement (summary) | NIST control | NYDFS ref | PCI DSS ref |
|--------|---------|----------------------|--------------|-----------|-------------|
| [IAM Policy] | | | | | |
| [SDLC Policy] | | | | | |
| [Logging & Monitoring Policy] | | | | | |
| [Asset Management Policy] | | | | | |
| [Data Governance Policy] | | | | | |

---

## Section 6 — Quick Lookup: Scenario → Controls

| Scenario | Primary controls | Policy areas |
|----------|-----------------|--------------|
| Stale/orphaned account found | AC-2, AC-2(3), NYDFS §500.7 | IAM, Asset Mgmt |
| Service account with no app mapping | AC-2, CM-8, NYDFS §500.7, PCI 8.6 | IAM, Asset Mgmt |
| MFA not enforced for privileged user | IA-2(1), NYDFS §500.12, PCI 8.4 | IAM, Security |
| Script with hardcoded credentials found | IA-5(7), SA-11, CM-6 | SDLC, IAM |
| Logs not forwarded to SIEM | AU-2, AU-12, NYDFS §500.14 | Logging & Monitoring |
| Access not reviewed in 12 months | AC-2, AC-5, NYDFS §500.7 | IAM, Governance |
| Non-domain-joined server with no auth control | AC-2, AC-17, NYDFS §500.7 | IAM, Asset Mgmt |
| Excessive privilege / admin rights | AC-6, AC-6(2), NYDFS §500.7, PCI 7.1 | IAM, PAM |
| Terminated user account still active | AC-2, PS-4, NYDFS §500.7 | IAM, HR |
| Change made without CAB approval | CM-3, CM-5 | SDLC, Change Mgmt |
| Certificate expired / unmanaged | SC-17, CM-8 | Security, Asset Mgmt |
| OIG fulfiller script with no code review | SA-3, SA-11, CM-3 | SDLC |
| Okta not sending logs to SIEM | AU-12, NYDFS §500.14 | Logging & Monitoring |
| RPA account with no review process | AC-2, NYDFS §500.7, PCI 8.6 | IAM, Governance |
