# CONTEXT.md — IAM Workspace Environment
# Load this file at the start of EVERY session.
# Last updated: 2026-05-16

---

## Role & Escalation Position
- **Title**: IAM Senior Lead Engineer (Principal-track)
- **Function**: Last line of escalation across all IAM domains and all enterprise teams
- **Scope**: Tactical resolution + strategic recommendation + RCA for all high-severity IAM issues
- **Output standard**: Full package — tactical fix, RCA, strategic recommendation, reg/policy gap citation, ServiceNow update, Confluence doc

---

## Org Structure — Three Operating Companies (OpCos)
| OpCo | Code | Description |
|------|------|-------------|
| AM   | AM   | Primary OpCo — hosts core AD domain, ghost accounts for HS/MS |
| HS   | HS   | Secondary OpCo |
| MS   | MS   | Secondary OpCo |

**Identity correlation key**: `afiExternalUserID` — links all identity types across OpCos

---

## Identity Types
| Type | Category | Notes |
|------|----------|-------|
| Primary account | Human | User's primary OpCo domain account |
| Secondary account | Human | Affiliated account for secondary OpCo access |
| Ghost account | Human | Dummy account for HS/MS users created under AM OpCo directory |
| Service account (interactive) | NHI | Can log in interactively — highest risk |
| gMSA | NHI | Non-interactive managed service account |
| RPA account | NHI | Robotic process automation — no defined review/rotation process yet |

---

## HR / Identity Sources (Authoritative)
| Source | Manages | OpCo Scope |
|--------|---------|------------|
| Workday | Full-time employees | All 3 OpCos |
| Simplify | Contractors + vendors | All 3 OpCos |
| PMAC | Producers / agents | AM OpCo only |

---

## IAM Tool Stack — All 13 Tools

### Directory Services
| Tool | Role | Notes |
|------|------|-------|
| Active Directory | Multi-forest/multi-domain auth | Core, PCI, DMZ forests segmented. PCI = one-way trust. |
| Azure AD / Entra ID | Cloud identity, hybrid sync | Core domain synced via ADConnect |
| ADConnect | On-prem → Entra sync | Core domains only |
| Radiant Logic / RadiantOne VDS | Virtual directory aggregation | Aggregates identity from all directories |
| GroupID / Imanami | AD group lifecycle management | |

### Access Management
| Tool | Role | Notes |
|------|------|-------|
| Okta | SSO/federation, app access | Sync via agents from AD; manual CSV feed to OIG; migration to Entra underway |
| SiteMinder / CA Access Manager | Legacy web SSO | Protects on-prem apps not yet migrated |
| Conditional Access | Entra-based policy enforcement | MFA, device compliance, location policies |
| Specops Password Manager | Password policy + self-service reset | Primary accounts only; breach detection |
| Silverfort | Auth monitoring + MFA enforcement | Sees all auth events across environment |

### Privileged Access
| Tool | Role | Notes |
|------|------|-------|
| Arcon PAM | PAM vault, session brokering, JIT | Service accounts stored here; app retrieval programmatic |
| Arcon EPM | Endpoint privilege management | Local admin removal; elevation workflow |

### Identity Lifecycle & Governance
| Tool | Role | Notes |
|------|------|-------|
| OpenText NetIQ / MyAccess | ILM — provisioning/de-provisioning | Primary accounts only; creates mailbox + Entra license; 30-day rebadge window |
| OpenText Identity Governance (OIG) | RBAC, SoD, access reviews | In production but performance/functionality issues; IAM dept pilot only; Okta via manual CSV feed; fulfillers = standalone PowerShell scripts |

---

## Supporting Infrastructure
| Tool | Role |
|------|------|
| ServiceNow | ITSM — incidents, SRs, problems, changes, CMDB (APM#) |
| Google SecOps (SIEM) | All DC security logs + Entra logs via CRIBL |
| Datadog | Infrastructure monitoring — all servers; AD security event logs |
| XSOR | Automated workflow builder |
| Tableau / PowerBI | Dashboards |
| Keyfactor | Certificate authority management |
| Microsoft PKI | Directory services certificates |

---

## IAM Pillars (5)
1. Directory Services
2. Access Management
3. Privileged Access Management
4. Identity Administration
5. Identity Governance
+ CyberSquad (L1 operational support)

---

## Known Critical Gaps (summary — detail in gap-register.md)
- Service account → application mapping missing in CMDB (APM# has app owner, not svc acct)
- OIG in production but not enterprise-usable (performance + functionality issues)
- Okta → OIG feed is manual CSV, not API
- OIG fulfillers are standalone PowerShell scripts — no code review, no version control
- Ghost account lifecycle has no automated de-provisioning
- Non-domain-joined servers (Windows + Linux RHEL) outside AD policy scope
- RPA accounts have no defined review or rotation process
- Specops scope limited to primary accounts only
- Rebadging 30-day overlap — no entitlement freeze during transition

---

## Regulatory Frameworks (see QUICK-REF.md for digest)
- NIST SP 800-53 Rev5
- NIST SP 800-63-3 (IAL/AAL/FAL)
- NYDFS 23 NYCRR Part 500 (November 2023 amendment)
- PCI DSS v4.0

---

## Key Relationships (escalation map)
| Team | How they engage you |
|------|---------------------|
| Security Operations | Auth anomalies, SIEM alerts, threat correlation |
| Server Team | Service account issues, AD auth failures, GPO conflicts |
| End User Computing | EPM elevation issues, Autopilot/workstation identity, Specops |
| Governance | Policy compliance, control evidence, audit prep |
| Risk Assessment | Risk ratings, gap severity, remediation timelines |
| Compliance | NYDFS/PCI/NIST evidence, regulatory mapping |
| Cyber Threat Intel | IOC correlation with identity events, lateral movement |
| Application Developers | Service account provisioning, SCIM, OAuth, SAML federation |
| Enterprise Architects | Identity architecture decisions, tool consolidation |
| Solution Architects | Integration design, federation patterns |
| Principals / Leadership | Strategic direction, maturity assessment, roadmap |
