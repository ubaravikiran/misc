# FINDING_FORMAT.md — Standard Finding Template
# Claude outputs every finding in this exact format.
# Ensures consistency across assessment, daily ops, and RCA work.

---

## Finding Record Template

```
FINDING ID:       IAM-[3-digit sequential number]-[tool-short-code]
DATE:             [YYYY-MM-DD]
IDENTIFIED BY:    IAM Senior Lead Engineer
SESSION TYPE:     [ assessment | escalation | consultation | proactive ]

---

## 1. Finding Summary
One sentence. What is wrong, in which tool, and what is the risk.

## 2. Observation
What was observed. Specific — system name, account name, config value, export row.
Reference the evidence artifact: evidence/[folder]/[filename] — row/line [x].

## 3. Root Cause
Why this exists. Technical root cause. If unknown, state hypothesis and what is needed to confirm.

## 4. Business Impact
What happens if this is not remediated. Quantify where possible (# accounts affected, # systems exposed).

## 5. Regulatory & Policy Violations
| Framework | Control/Section | Requirement | Status |
|-----------|----------------|-------------|--------|
| NIST 800-53 Rev5 | [control ID] | [one-line requirement] | Non-compliant / Partial |
| NYDFS Part 500 | [§xxx.x] | [one-line requirement] | Non-compliant / Partial |
| PCI DSS v4.0 | [Req x.x] | [one-line requirement] | Non-compliant / Partial |
| [Enterprise Policy] | [§x.x] | [one-line requirement] | Non-compliant / Partial |

## 6. Severity Rating
[ Critical | High | Medium | Low ]

Rationale: [1-2 sentences explaining the rating]

## 7. Tactical Recommendation (immediate)
What to do right now to reduce risk or remediate. Step-by-step if possible.
Owner: [team or person]
Timeline: [e.g., 24 hours / 7 days / 30 days]

## 8. Strategic Recommendation (long-term)
What the permanent fix looks like. May involve tooling, process, or policy change.
Owner: [team or person]
Timeline: [e.g., Q3 2026]
Linked initiative: [e.g., OIG stabilization / Entra migration / EPM expansion]

## 9. Evidence Artifacts
- [ ] [filename] — attached to evidence/[tool]/
- [ ] [screenshot name] — attached to evidence/[tool]/
- [ ] [command output] — inline below or attached

## 10. ServiceNow Fields
Type:          [ Incident | Problem | Change | Service Request ]
Priority:      [ P1 | P2 | P3 | P4 ]
Assignment:    [team]
Short desc:    [max 80 chars — copy-paste ready]
Work notes:    [paste finding sections 2-5 here]

## 11. Status
[ Open | In Progress | Risk Accepted | Remediated | Verified ]
Last updated: [DATE]
```

---

## Severity Rating Guide

| Rating | Definition | Examples |
|--------|-----------|---------|
| Critical | Active exploitation possible or regulatory breach with exam risk | Hardcoded creds in prod, MFA bypass active, privileged account unvaulted |
| High | Significant control failure, exploitable with moderate effort | Stale admin accounts, PAM session recording off, logs not in SIEM |
| Medium | Control gap, not immediately exploitable, compliance gap | Access review overdue, Specops not covering secondary accounts |
| Low | Best practice deviation, low exploitability | Naming convention inconsistency, GPO documentation missing |

---

## Tool Short Codes (for Finding IDs)
| Code | Tool |
|------|------|
| AD | Active Directory |
| ENTRA | Azure AD / Entra ID |
| CA | Conditional Access |
| OKTA | Okta |
| SM | SiteMinder |
| NETIQ | NetIQ / MyAccess |
| OIG | OpenText Identity Governance |
| ARCPAM | Arcon PAM |
| ARCEPM | Arcon EPM |
| SPEC | Specops Password Manager |
| RL | Radiant Logic |
| SF | Silverfort |
| GID | GroupID |
| CROSS | Cross-tool / cross-domain finding |
